
# Frontend - Consumo de API

## 1. Objetivo
Definir como el frontend debe consumir la API ya especificada.

## 2. Servicios frontend sugeridos
- `authApi`
- `ticketApi`
- `scanFileApi`
- `integrationApi`
- `adminApi`
- `auditApi`

## 3. ticketApi

### Metodos sugeridos
- `searchTickets(filters)`
- `getTicketById(ticketId)`
- `getTicketItems(ticketId)`
- `getTicketStores(ticketId)`
- `getFullTicket(ticketId)`

## 4. scanFileApi

### Metodos sugeridos
- `getActiveScanFile(ticketId)`
- `uploadOrReplaceScanFile(ticketId, formData)`
- `confirmScanFile(ticketId, body)`
- `downloadOrViewActiveScanFile(ticketId)`
- `getScanFileHistory(ticketId)`

## 5. integrationApi
- `searchBatches(filters)`
- `getBatchById(batchId)`
- `getBatchFiles(batchId)`
- `getBatchErrors(batchId)`

## 6. adminApi
- `searchUsers(filters)`
- `getUserById(userId)`
- `createUser(body)`
- `updateUser(userId, body)`
- `changeUserStatus(userId, body)`
- `getUserStores(userId)`
- `assignStore(userId, body)`
- `removeStore(userId, storeCode)`

## 7. auditApi
- `searchAuditEvents(filters)`

## 8. Ejemplos de consumo

### Buscar tickets
```text
GET /api/v1/tickets?page=1&pageSize=20&scanStatus=NO_FILE
```

### Obtener ticket completo
```text
GET /api/v1/tickets/1001/full
```

### Upload archivo
```text
POST /api/v1/tickets/1001/scan-file
multipart/form-data
```

### Confirm archivo
```text
PUT /api/v1/tickets/1001/scan-file/confirm
```

## 9. Manejo de auth token
Cada request autenticado debe incluir:
```http
Authorization: Bearer <token>
```

## 10. Manejo de errores en cliente
Crear un `apiErrorMapper` que traduzca:
- `401` -> redireccion al login o refresh
- `403` -> pantalla sin permisos / toast
- `404` -> not found view
- `409/422` -> mensaje de regla de negocio
- `500` -> error generico

## 11. Estrategia de refresco de pantalla
Despues de:
- upload/reemplazo
- confirmacion

se recomienda refrescar al menos:
- detalle del ticket
- resumen del archivo activo

## 12. Estrategia de cache sugerida
- cache corta para consultas de detalle y listas
- invalidar cache de ticket despues de upload/confirm
- invalidar cache de listados si se muestran contadores dependientes del estado documental
