
# Frontend - Flujos y Navegacion

## 1. Flujo principal de usuario de tienda

```text
Login
  -> Dashboard
  -> Busqueda de tickets
  -> Detalle de ticket
  -> Archivo escaneado
      -> Cargar/Reemplazar
      -> Confirmar
      -> Ver archivo
```

## 2. Flujo principal de supervisor

```text
Login
  -> Dashboard
  -> Busqueda global de tickets
  -> Detalle de ticket
  -> Ver archivo
  -> (Opcional) Lotes
```

## 3. Flujo principal de admin

```text
Login
  -> Dashboard
  -> Tickets
  -> Integracion / Lotes
  -> Usuarios
  -> Asignacion de tiendas
  -> Auditoria
```

## 4. Navegacion sugerida por rutas

```text
/login
/dashboard
/tickets
/tickets/:ticketId
/tickets/:ticketId/items   (opcional, si se separa)
/tickets/:ticketId/stores  (opcional)
/tickets/:ticketId/scan-file (opcional)
/integration/batches
/integration/batches/:batchId
/admin/users
/admin/users/:userId
/admin/users/:userId/stores
/audit/events
```

## 5. Deep linking recomendado
La UI debe permitir abrir directamente:
- un ticket por id
- un lote por id
- un usuario por id

## 6. Flujo de detalle de ticket

### Opcion A
Una sola vista `/tickets/:ticketId` con tabs internas.

### Opcion B
Subrutas por pestaña.

### Recomendacion
Usar **una sola vista con tabs** para reducir complejidad del usuario.

## 7. Flujo de carga/reemplazo de archivo
1. usuario entra al detalle
2. ve estado `NO_FILE` o `FILE_UPLOADED`
3. selecciona archivo
4. UI valida extension/tamanio
5. muestra confirmacion de envio
6. ejecuta upload
7. refresca metadata del archivo

## 8. Flujo de confirmacion de archivo
1. usuario ve archivo activo no confirmado
2. selecciona `Confirmar`
3. UI pide confirmacion (modal)
4. ejecuta endpoint de confirm
5. refresca vista
6. cambia estado a `FILE_CONFIRMED`

## 9. Flujo de monitoreo de lotes
1. admin entra a `Lotes`
2. filtra por fecha/estatus
3. selecciona lote
4. ve detalle del lote
5. ve archivos y errores

## 10. Breadcrumbs sugeridos

### Ejemplos
- `Dashboard / Tickets`
- `Dashboard / Tickets / Ticket 1001`
- `Dashboard / Integracion / Lote 20260618_090000`
- `Dashboard / Administracion / Usuarios / Usuario 25`
