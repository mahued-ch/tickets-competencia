
# Frontend - Arquitectura y Principios

## 1. Objetivo
Definir una arquitectura funcional clara para la aplicacion web.

## 2. Tipo de aplicacion recomendado
Se recomienda una **Single Page Application (SPA)** corporativa.

## 3. Modulos funcionales del frontend
- autenticacion / loading de contexto de usuario
- dashboard
- tickets (busqueda, detalle, items, stores)
- archivo escaneado
- monitoreo de lotes
- administracion (usuarios, asignacion de tiendas)
- auditoria

## 4. Estructura sugerida del frontend

```text
src/
  app/
    routing/
    layouts/
    guards/
  modules/
    auth/
    dashboard/
    tickets/
    scan-file/
    integration/
    admin/
    audit/
  shared/
    components/
    services/
    hooks-or-state/
    models/
    utils/
    constants/
```

## 5. Principios UX del sistema
1. priorizar busqueda y consulta rapida;
2. mostrar claramente el estado del ticket y del archivo escaneado;
3. ocultar visualmente acciones no permitidas por rol o estado;
4. minimizar pasos para carga/confirmacion del archivo;
5. mantener consistencia visual en tablas, filtros y formularios.

## 6. Principios tecnicos del frontend
1. separación entre vistas, estado y servicios API;
2. DTOs de API no deben mezclarse con componentes sin normalizacion;
3. manejo centralizado de errores;
4. paginacion y filtros persistentes por vista cuando aplique;
5. soporte a navegacion por URL profunda en pantallas de consulta.

## 7. Estado global sugerido
Mantener en estado global o contexto compartido:
- usuario autenticado
- rol del usuario
- tiendas asignadas
- configuracion general de UI
- correlation/request id si se desea observar trazabilidad

## 8. Seguridad visual
La UI debe reflejar la seguridad, pero NO sustituye la seguridad backend.

### Reglas
- `STORE_USER`: solo menus y acciones que le correspondan
- `SUPERVISOR`: acceso de consulta global
- `ADMIN`: acceso completo a modulos administrativos

## 9. Layout sugerido
- header con nombre de modulo y usuario actual
- menu lateral por rol
- area central de trabajo
- breadcrumbs en vistas de detalle
- barra de acciones contextual

## 10. Estrategia responsive
Se recomienda:
- desktop-first para operacion;
- responsive basico para tablet;
- movil no prioritario si no es requisitio del negocio.
