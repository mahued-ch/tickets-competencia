
# Frontend - Componentes y Estados UI

## 1. Componentes compartidos sugeridos

### 1.1 DataTable
Para:
- tickets
- lotes
- errores
- usuarios
- auditoria

Debe soportar:
- paginacion
- sort
- columnas configurables
- empty state
- loading state

### 1.2 FilterBar
Para encapsular filtros de listado.

### 1.3 StatusBadge
Para estados como:
- `NO_FILE`
- `FILE_UPLOADED`
- `FILE_CONFIRMED`
- estados de lote

### 1.4 FileUploadField
Componente para seleccionar archivo, validar extension y tamanio.

### 1.5 ConfirmationModal
Para:
- confirmar archivo
- acciones administrativas sensibles

### 1.6 DetailPanel / Tabs
Para detalle del ticket.

## 2. Estados UI globales

### Loading
Mostrar skeleton o spinner consistente.

### Empty
Mostrar mensaje claro, por ejemplo:
- `No se encontraron tickets`
- `No hay archivo escaneado`
- `No hay errores registrados`

### Error
Mostrar mensaje amigable y opcion de reintento si aplica.

## 3. Estados de pantalla - Tickets List
- initial
- loading
- loaded with results
- loaded empty
- error

## 4. Estados de pantalla - Ticket Detail
- loading
- loaded
- forbidden
- not found
- error

## 5. Estados de pantalla - Archivo escaneado

### `NO_FILE`
- mensaje: `Este ticket no tiene archivo escaneado`
- accion posible: `Cargar archivo` si permitido

### `FILE_UPLOADED`
- mostrar metadata
- acciones: `Reemplazar`, `Confirmar`, `Ver archivo`

### `FILE_CONFIRMED`
- mostrar metadata
- acciones: solo `Ver archivo`
- mostrar leyenda: `Archivo confirmado, ya no puede modificarse`

## 6. Campos visibles sugeridos en la vista de resumen del ticket
- ticketId
- sourceTicketKey
- sourceStatusCode
- sourceTicketDate
- scanStatus
- hasScanFile
- lote de integracion (opcional visible para roles elevados)

## 7. Campos visibles sugeridos del archivo
- fileName
- mimeType
- fileSizeBytes
- versionNumber
- isConfirmed
- uploadedAt
- confirmedAt

## 8. Modal de confirmacion sugerido

### Titulo
`Confirmar archivo escaneado`

### Mensaje
`Una vez confirmado, el archivo ya no podra reemplazarse. Desea continuar?`

### Botones
- `Cancelar`
- `Confirmar`

## 9. Historial de versiones (opcional)
Si se implementa, mostrarlo como tabla simple con:
- versionNumber
- fileName
- uploadedAt
- isActive
- isConfirmed
- replacedByFileId
