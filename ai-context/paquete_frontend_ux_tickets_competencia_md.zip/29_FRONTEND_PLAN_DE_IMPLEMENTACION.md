
# Frontend - Plan de Implementacion

## 1. Objetivo
Proponer un orden realista de construccion del frontend.

## 2. Fase 1 - Fundacion
### Entregables
- shell de aplicacion
- layout principal
- router
- auth guard base
- cliente HTTP centralizado
- manejo global de errores y notificaciones

### Checklist
- [ ] layout
- [ ] menu lateral
- [ ] ruta login
- [ ] auth context/store
- [ ] http client con bearer token
- [ ] manejador de errores global

## 3. Fase 2 - Tickets
### Entregables
- vista de lista
- filtros
- paginacion
- detalle del ticket
- items
- stores

### Checklist
- [ ] modulo tickets
- [ ] DataTable base
- [ ] FilterBar
- [ ] detalle con tabs

## 4. Fase 3 - Archivo escaneado
### Entregables
- componente upload
- metadata del archivo
- modal de confirmacion
- visualizacion/descarga
- historial opcional

### Checklist
- [ ] FileUploadField
- [ ] ConfirmationModal
- [ ] flujo upload
- [ ] flujo confirm
- [ ] viewer/download

## 5. Fase 4 - Integracion y monitoreo
### Entregables
- lista de lotes
- detalle de lote
- errores de lote

## 6. Fase 5 - Administracion
### Entregables
- usuarios
- asignacion de tiendas
- auditoria

## 7. Fase 6 - Endurecimiento
### Entregables
- refinamiento UX
- permisos por vista
- loading skeletons
- empty states
- pruebas UI

## 8. Criterio de done frontend
Frontend minimo util cuando exista:
1. login/contexto de usuario;
2. lista y detalle de tickets;
3. upload/reemplazo/confirmacion de archivo;
4. seguridad visual por rol;
5. modulo de lotes para admin;
6. mensajes y estados UI consistentes.
