
# Frontend - Mapa de Pantallas y Roles

## 1. Pantallas principales

### 1. Login
Disponible para todos los usuarios autenticables.

### 2. Dashboard
Resumen operativo de tickets y accesos rapidos.

### 3. Busqueda de Tickets
Pantalla principal de consulta.

### 4. Detalle de Ticket
Vista con cabecera, items, stores y resumen del archivo.

### 5. Archivo Escaneado
Seccion dentro del detalle para:
- cargar/reemplazar archivo
- confirmar archivo
- visualizar archivo
- ver historial (si se implementa)

### 6. Monitoreo de Lotes
Consulta de lotes procesados, archivos y errores.

### 7. Administracion de Usuarios
Alta, edicion, activacion/desactivacion.

### 8. Asignacion de Tiendas
Asociacion de tiendas a usuarios.

### 9. Auditoria
Consulta de eventos relevantes.

## 2. Matriz de acceso por rol

### STORE_USER
- Login: si
- Dashboard: si
- Busqueda de tickets: si (solo sus tickets)
- Detalle de ticket: si (si ticket visible)
- Carga/reemplazo/confirmacion de archivo: si
- Monitoreo de lotes: no
- Administracion: no
- Auditoria: no

### SUPERVISOR
- Login: si
- Dashboard: si
- Busqueda de tickets: si (global)
- Detalle de ticket: si
- Visualizacion de archivo: si
- Carga/confirmacion: opcional segun politica final
- Monitoreo de lotes: opcional / recomendado lectura
- Administracion: no
- Auditoria: opcional lectura

### ADMIN
- Todo lo anterior
- Monitoreo de lotes: si
- Administracion de usuarios: si
- Asignacion de tiendas: si
- Auditoria: si

## 3. Menu sugerido por rol

### Menu STORE_USER
- Dashboard
- Tickets
- Mi perfil (opcional)

### Menu SUPERVISOR
- Dashboard
- Tickets
- Lotes (si habilitado)

### Menu ADMIN
- Dashboard
- Tickets
- Integracion / Lotes
- Usuarios
- Asignacion de tiendas
- Auditoria

## 4. Vistas del modulo Tickets

### 4.1 Lista de tickets
Elementos:
- barra de filtros
- tabla de resultados
- paginacion
- acciones por fila (ver detalle)

### 4.2 Detalle del ticket
Pestañas o secciones sugeridas:
- Resumen del ticket
- Items
- Tiendas
- Archivo escaneado
- Historial (opcional)

## 5. Reglas visuales por estado del archivo

### `NO_FILE`
- mostrar boton `Cargar archivo` si corresponde
- mostrar estado visible tipo badge

### `FILE_UPLOADED`
- mostrar metadata del archivo
- mostrar botones `Reemplazar` y `Confirmar` si usuario puede operar

### `FILE_CONFIRMED`
- mostrar metadata del archivo
- ocultar/bloquear `Reemplazar`
- ocultar/bloquear `Confirmar`
- dejar solo `Ver archivo`
