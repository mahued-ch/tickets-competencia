
# Frontend - Validaciones y Mensajes

## 1. Objetivo
Centralizar validaciones de UI y mensajes sugeridos para consistencia funcional.

## 2. Validaciones del upload

### Extension permitida
Mensajes sugeridos:
- `El tipo de archivo no es valido. Solo se permiten PDF, JPG, JPEG o PNG.`

### Tamanio permitido
Mensaje sugerido:
- `El archivo excede el tamanio maximo permitido.`

### Archivo requerido
Mensaje sugerido:
- `Debe seleccionar un archivo.`

## 3. Mensajes por estado del ticket/archivo

### No permitido por estatus origen
- `Este ticket no permite adjuntar archivo porque su estatus de origen no es 9.`

### Archivo no encontrado
- `No existe archivo escaneado para este ticket.`

### Archivo confirmado
- `El archivo ya esta confirmado y no puede reemplazarse.`

### Confirmacion exitosa
- `El archivo fue confirmado correctamente.`

### Reemplazo exitoso
- `El archivo fue cargado/reemplazado correctamente.`

## 4. Mensajes por autorizacion

### Sin permisos de ticket
- `No tiene permisos para consultar u operar este ticket.`

### Sin permisos de admin
- `No tiene permisos para acceder a este modulo.`

## 5. Mensajes de integracion

### Lote sin errores
- `Lote procesado correctamente.`

### Lote con errores
- `El lote fue procesado con errores.`

### Lote no encontrado
- `No existe el lote solicitado.`

## 6. Recomendacion UX
Usar mensajes:
- claros
- cortos
- orientados a accion
- consistentes entre modulos

## 7. Toasts sugeridos
- guardado exitoso
- carga de archivo exitosa
- confirmacion exitosa
- error al procesar la accion

## 8. Mensajes de empty state
- `No se encontraron tickets para los filtros seleccionados.`
- `No hay lotes para el criterio indicado.`
- `Este usuario no tiene tiendas asignadas.`
