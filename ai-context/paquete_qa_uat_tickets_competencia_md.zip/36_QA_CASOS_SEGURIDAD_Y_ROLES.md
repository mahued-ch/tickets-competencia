
# QA - Casos de Seguridad y Roles

## 1. Objetivo
Validar autorizacion por rol y por tienda.

---

## Caso SEC-001 - STORE_USER solo ve tickets de sus tiendas
### Resultado esperado
- solo tickets con stores asignadas al usuario

---

## Caso SEC-002 - STORE_USER no ve ticket ajeno
### Resultado esperado
- `403` o ausencia del ticket en la lista

---

## Caso SEC-003 - SUPERVISOR ve tickets globales
### Resultado esperado
- puede consultar tickets de cualquier tienda

---

## Caso SEC-004 - ADMIN accede a modulos administrativos
### Resultado esperado
- puede consultar lotes, usuarios y auditoria

---

## Caso SEC-005 - STORE_USER bloqueado de administracion
### Resultado esperado
- no ve menues admin
- `403` si intenta acceder por URL

---

## Caso SEC-006 - STORE_USER bloqueado de lotes
### Resultado esperado
- sin acceso a `integration/batches`

---

## Caso SEC-007 - Usuario inactivo
### Resultado esperado
- no autentica o no puede operar

---

## Caso SEC-008 - Token invalido
### Resultado esperado
- `401 Unauthorized`
