
# QA - Casos del Archivo Escaneado

## 1. Objetivo
Validar el flujo completo del archivo escaneado.

---

## Caso SCN-001 - Upload inicial permitido
### Precondiciones
- ticket visible al usuario
- `source_status_code = '9'`
- no existe archivo activo

### Pasos
1. abrir detalle del ticket
2. cargar archivo valido
3. enviar

### Resultado esperado
- upload exitoso
- `scanStatus = FILE_UPLOADED`
- `hasScanFile = true`
- version 1 creada

---

## Caso SCN-002 - Upload no permitido por status
### Precondiciones
- ticket con `source_status_code != '9'`

### Resultado esperado
- no se permite upload
- mensaje de negocio claro
- backend regresa `409` o `422`

---

## Caso SCN-003 - Reemplazo antes de confirmar
### Precondiciones
- existe archivo activo no confirmado

### Pasos
1. cargar nuevo archivo valido
2. enviar reemplazo

### Resultado esperado
- se crea nueva version
- version anterior deja de estar activa
- el ticket sigue `FILE_UPLOADED`

---

## Caso SCN-004 - Confirmacion de archivo
### Precondiciones
- existe archivo activo no confirmado

### Pasos
1. seleccionar `Confirmar`
2. aceptar modal

### Resultado esperado
- archivo queda confirmado
- ticket queda `FILE_CONFIRMED`
- se bloquean acciones de reemplazo

---

## Caso SCN-005 - Reemplazo despues de confirmar
### Precondiciones
- archivo activo confirmado

### Resultado esperado
- no se permite reemplazo
- mensaje: archivo ya confirmado

---

## Caso SCN-006 - Confirmar sin archivo activo
### Resultado esperado
- no se permite confirmacion
- error `ACTIVE_SCAN_FILE_NOT_FOUND`

---

## Caso SCN-007 - Visualizar archivo
### Precondiciones
- existe archivo activo

### Resultado esperado
- se visualiza/descarga archivo correcto
- nombre y mimeType correctos

---

## Caso SCN-008 - Archivo con extension invalida
### Resultado esperado
- bloqueo en frontend y/o backend
- mensaje adecuado

---

## Caso SCN-009 - Archivo excede limite
### Resultado esperado
- bloqueo de upload
- mensaje adecuado
