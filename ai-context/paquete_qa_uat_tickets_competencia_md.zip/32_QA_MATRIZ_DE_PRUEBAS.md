
# QA - Matriz de Pruebas

## 1. Objetivo
Proveer una matriz resumida de los modulos y lo que debe probarse en cada uno.

## 2. Matriz general

### Modulo: Autenticacion
- login exitoso
- acceso con token invalido
- acceso con usuario inactivo
- resolucion correcta de rol y tiendas

### Modulo: Tickets
- busqueda con filtros
- paginacion
- detalle por id
- items del ticket
- stores del ticket
- busqueda restringida por tienda

### Modulo: Archivo escaneado
- consulta sin archivo
- upload inicial con status 9
- reemplazo antes de confirmar
- confirmacion
- bloqueo despues de confirmar
- visualizacion del archivo

### Modulo: Integracion
- procesamiento de lote completo
- lote incompleto
- lote duplicado
- errores de parseo JSON
- carga a staging
- consolidacion operativa
- movimiento a `ARCHIVE`/`ERROR`

### Modulo: Seguridad
- `STORE_USER` solo ve sus tickets
- `SUPERVISOR` ve global
- `ADMIN` accede a admin/integration/audit
- `STORE_USER` bloqueado de admin/integration

### Modulo: Administracion
- alta de usuario
- actualizacion de usuario
- activacion/desactivacion
- asignacion/desasignacion de tienda

### Modulo: Auditoria
- eventos de upload/reemplazo/confirmacion
- consulta filtrada de auditoria

## 3. Criterios de cobertura minima
Para cada regla critica deben existir:
- 1 caso feliz
- 1 caso negativo de permiso
- 1 caso negativo de estado
- 1 caso de dato inexistente cuando aplique

## 4. Priorizacion sugerida

### P0 (critico)
- seguridad por tienda
- upload/replace/confirm de scan-file
- integracion de ticket nuevo
- no duplicidad de ticket

### P1 (alto)
- filtros y paginacion
- monitoreo de lotes
- administracion de usuarios

### P2 (medio)
- historial opcional del archivo
- dashboard
- refinamientos de auditoria
