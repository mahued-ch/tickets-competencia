
# QA - Estrategia General

## 1. Objetivo
Definir la estrategia integral de pruebas para validar el sistema completo.

## 2. Objetivos de QA
1. validar que las reglas de negocio se cumplan;
2. validar que la integracion JSON funcione correctamente;
3. validar la seguridad por rol y tienda;
4. validar el flujo del archivo escaneado;
5. validar consistencia entre frontend, backend y BD;
6. reducir el riesgo antes de UAT y salida a productivo.

## 3. Niveles de prueba

### 3.1 Pruebas unitarias
Apuntan a:
- policies de dominio;
- validadores;
- mappers;
- funciones auxiliares del importador.

### 3.2 Pruebas de integracion
Apuntan a:
- repositories;
- funciones SQL;
- importador JSON -> BD;
- storage service;
- streams del archivo escaneado.

### 3.3 Pruebas funcionales / API
Apuntan a:
- endpoints REST;
- autenticacion/autorizacion;
- respuestas y codigos HTTP;
- contratos JSON.

### 3.4 Pruebas end-to-end funcionales
Apuntan a:
- flujos de usuario en frontend;
- navegacion;
- upload/confirmacion de archivo;
- seguridad por rol.

### 3.5 UAT
Apunta a:
- validacion con usuarios clave;
- conformidad del comportamiento con la operacion esperada;
- aceptacion funcional del sistema.

## 4. Alcance minimo que se debe probar
- integracion de lotes;
- consulta de tickets;
- consulta de items y stores;
- upload/reemplazo/confirmacion de archivo;
- visualizacion de archivo;
- seguridad por rol/tienda;
- usuarios y asignacion de tiendas;
- auditoria y monitoreo basico.

## 5. Fuera del alcance de QA inicial
- performance testing profundo de tipo carga masiva (si no hay ambiente/herramienta);
- pentesting formal;
- pruebas movil nativas;
- OCR o AI (fuera del alcance actual del proyecto).

## 6. Fases recomendadas de validacion

### Fase 1
Pruebas tecnicas base:
- BD
- funciones SQL
- importador

### Fase 2
Pruebas API:
- tickets
- scan-file
- admin
- integration

### Fase 3
Pruebas frontend:
- navegacion
- estados UI
- errores esperados

### Fase 4
UAT con usuarios clave.

## 7. Principios de prueba
1. cada regla critica debe tener prueba positiva y negativa;
2. probar por rol;
3. probar datos inexistentes y datos validos;
4. probar estados permitidos y no permitidos;
5. registrar evidencia por caso.

## 8. Artefactos esperados de QA
- plan de pruebas;
- matriz de casos;
- set de datos de prueba;
- evidencia de ejecucion;
- log de defectos;
- reporte de salida.
