
# QA - Casos de Integracion y Lotes

## 1. Objetivo
Validar la integracion JSON y el manejo de lotes.

---

## Caso INT-001 - Lote completo exitoso
### Precondiciones
- existen 4 archivos del mismo batchCode
- JSON validos

### Pasos
1. ejecutar importador

### Resultado esperado
- se crea `integration_batch`
- se crean `integration_file`
- se insertan staging rows
- se consolidan tickets nuevos
- archivos movidos a `ARCHIVE`
- estatus final `PROCESSED` o `ARCHIVED`

---

## Caso INT-002 - Falta control.json
### Resultado esperado
- lote no se procesa
- se registra como incompleto/fallo controlado

---

## Caso INT-003 - Falta header/items/stores
### Resultado esperado
- lote no se procesa
- error claro registrado

---

## Caso INT-004 - JSON invalido
### Resultado esperado
- error en `integration_error`
- lote `FAILED` o `PROCESSED_WITH_ERRORS`

---

## Caso INT-005 - Ticket duplicado
### Precondiciones
- ticket ya existe en operativa
- llega nuevamente en otro lote

### Resultado esperado
- no se reinserta
- `skippedTicketCount` aumenta
- resto del lote continua

---

## Caso INT-006 - Item sin header
### Resultado esperado
- no consolidar item huerfano
- registrar error

---

## Caso INT-007 - Store sin header
### Resultado esperado
- no consolidar store huerfano
- registrar error

---

## Caso INT-008 - Error al mover archivos a ARCHIVE
### Resultado esperado
- lote registrado correctamente hasta consolidacion
- error tecnicamente visible
- no perder trazabilidad del lote
