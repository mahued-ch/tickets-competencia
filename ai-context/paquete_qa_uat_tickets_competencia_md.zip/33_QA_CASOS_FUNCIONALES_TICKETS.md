
# QA - Casos Funcionales de Tickets

## 1. Objetivo
Detallar casos funcionales de consulta de tickets.

---

## Caso TCK-001 - Buscar tickets visibles para STORE_USER
### Precondiciones
- usuario `STORE_USER_A` existe y tiene tienda `0123`
- existen tickets aplicables a `0123`

### Pasos
1. iniciar sesion como `STORE_USER_A`
2. abrir pantalla de tickets
3. ejecutar busqueda sin filtros

### Resultado esperado
- solo se muestran tickets visibles para tiendas asignadas
- no se muestran tickets de `0456` si no estan asignados

---

## Caso TCK-002 - Buscar ticket por sourceTicketKey
### Precondiciones
- existe ticket con `sourceTicketKey` valido

### Pasos
1. buscar por `sourceTicketKey`

### Resultado esperado
- se regresa el ticket correcto
- si el usuario no tiene permiso, se bloquea

---

## Caso TCK-003 - Ver detalle de ticket
### Pasos
1. entrar al detalle del ticket

### Resultado esperado
- se muestra cabecera
- se muestra `scanStatus`
- se muestra resumen del archivo

---

## Caso TCK-004 - Consultar items del ticket
### Resultado esperado
- se muestran todas las lineas esperadas
- secuencia correcta
- montos consistentes con el dataset de prueba

---

## Caso TCK-005 - Consultar stores del ticket
### Resultado esperado
- se muestran todas las tiendas aplicables del ticket

---

## Caso TCK-006 - Paginacion
### Pasos
1. buscar tickets con dataset suficiente
2. moverse entre paginas

### Resultado esperado
- totalRecords/totalPages correctos
- resultados consistentes por pagina

---

## Caso TCK-007 - Ticket inexistente
### Pasos
1. abrir ticketId inexistente

### Resultado esperado
- respuesta `404` en API o vista `No encontrado` en UI

---

## Caso TCK-008 - Forbidden por tienda
### Precondiciones
- `STORE_USER_A` no tiene tienda del ticket

### Resultado esperado
- no puede consultar el ticket
- `403` o pantalla sin permisos
