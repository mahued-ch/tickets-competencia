
# QA - Criterios de Aceptacion y Salida

## 1. Objetivo
Definir cuando el sistema puede considerarse aprobado para UAT o productivo.

## 2. Criterios de aceptacion funcional
El sistema se considera funcionalmente aceptable si:
1. integra tickets nuevos sin duplicar;
2. permite consultar tickets por filtros y detalle;
3. respeta seguridad por tienda;
4. permite upload/reemplazo/confirmacion segun reglas;
5. impide operacion sobre archivo confirmado;
6. monitorea lotes y errores basicos;
7. administra usuarios y tiendas (si esta en alcance del release).

## 3. Criterios de salida de QA
Se recomienda no liberar a UAT o productivo si existe algun defecto abierto de severidad critica que afecte:
- seguridad por tienda
- integracion de lotes
- duplicidad de tickets
- flujo de archivo escaneado
- confirmacion/bloqueo de archivo

## 4. Clasificacion sugerida de defectos

### Critico
- fuga de tickets entre tiendas
- reemplazo de archivo confirmado
- integrador duplica tickets
- confirmacion no bloquea reemplazo

### Alto
- errores frecuentes de consulta
- filtros principales no funcionan
- upload falla sin causa clara

### Medio
- mensajes incorrectos
- problemas menores de UI
- detalles de paginacion o formato

### Bajo
- textos menores
- alineacion visual
- refinamientos no bloqueantes

## 5. Checklist de salida a UAT
- [ ] DDL desplegado
- [ ] importador funcional
- [ ] endpoints principales probados
- [ ] frontend tickets operativo
- [ ] scan-file operativo
- [ ] roles probados
- [ ] sin defectos criticos abiertos

## 6. Checklist de salida a produccion
- [ ] UAT completado y aprobado
- [ ] evidencia de casos P0/P1 ejecutados
- [ ] seguridad validada
- [ ] respaldo/restore definido
- [ ] monitoreo/logging disponible
- [ ] plan de reversa definido
