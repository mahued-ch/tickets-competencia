
# UAT - Guia para Usuarios Clave

## 1. Objetivo
Servir como guía de validacion para usuarios clave del negocio.

## 2. Perfil de participantes sugeridos
- usuario de tienda
- supervisor
- administrador funcional/soporte

## 3. Que validar en UAT

### Usuario de tienda
- encuentra sus tickets
- no ve tickets de otras tiendas
- puede cargar archivo cuando corresponde
- puede reemplazar antes de confirmar
- puede confirmar
- puede visualizar el archivo

### Supervisor
- consulta tickets globales
- entiende estados del ticket y del archivo
- puede dar seguimiento a pendientes

### Admin
- consulta lotes
- revisa errores
- administra usuarios/tiendas
- consulta auditoria

## 4. Escenarios minimos de UAT
1. buscar ticket propio
2. abrir detalle
3. cargar archivo donde aplique
4. confirmar archivo
5. intentar reemplazar confirmado
6. validar restricciones de seguridad
7. revisar lote importado

## 5. Evidencia sugerida
Registrar por caso:
- fecha/hora
- usuario ejecutor
- resultado esperado
- resultado real
- comentarios
- captura de pantalla si aplica

## 6. Plantilla simple de resultado UAT
```text
Caso:
Usuario:
Fecha:
Resultado esperado:
Resultado obtenido:
Aprobado: SI/NO
Observaciones:
```

## 7. Criterio de aprobacion UAT
Se recomienda considerar UAT aprobado cuando:
- usuarios clave aceptan el comportamiento principal
- no hay defectos criticos o altos abiertos sin plan
- el proceso operativo puede ejecutarse de punta a punta
