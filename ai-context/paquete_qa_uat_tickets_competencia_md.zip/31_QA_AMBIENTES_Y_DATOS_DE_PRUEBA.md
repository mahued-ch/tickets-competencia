
# QA - Ambientes y Datos de Prueba

## 1. Objetivo
Definir ambientes y data minima para ejecutar pruebas consistentes.

## 2. Ambientes sugeridos

### DEV
Uso de desarrolladores para pruebas unitarias y tecnicas iniciales.

### QA / TEST
Ambiente principal para ejecucion de casos funcionales, integracion y regresion.

### UAT
Ambiente para usuarios clave, idealmente con datos controlados y representativos.

## 3. Consideraciones del ambiente QA
Debe incluir:
- base de datos instalada y actualizada;
- backend desplegado;
- frontend desplegado;
- acceso controlado a carpeta inbound/ARCHIVE/ERROR;
- storage de archivo escaneado operativo;
- usuarios de prueba por rol.

## 4. Dataset minimo recomendado

### 4.1 Usuarios
Crear como minimo:
- 2 `STORE_USER`
- 1 `SUPERVISOR`
- 1 `ADMIN`

### 4.2 Tiendas
Crear como minimo:
- tienda `0123`
- tienda `0456`
- tienda `0789`

### 4.3 Asignaciones de tienda
- `STORE_USER_A` -> `0123`
- `STORE_USER_B` -> `0456`
- opcional multi-tienda para una prueba: `STORE_USER_A` -> `0123`, `0789`

### 4.4 Tickets de prueba
Se recomienda cargar al menos:
1. ticket visible para `STORE_USER_A`, con `source_status_code = '9'`, sin archivo
2. ticket visible para `STORE_USER_A`, con `source_status_code = '9'`, con archivo no confirmado
3. ticket visible para `STORE_USER_A`, con `source_status_code = '9'`, con archivo confirmado
4. ticket visible para `STORE_USER_B`, con `source_status_code = '7'`, sin archivo
5. ticket global no visible para `STORE_USER_A`

## 5. Lotes de prueba sugeridos
Preparar manualmente o con generador:
- lote completo exitoso
- lote con ticket duplicado
- lote con JSON mal formado
- lote sin control.json
- lote con item sin header
- lote con store sin header

## 6. Archivos de prueba para scan-file
Preparar:
- PDF valido pequeno
- PDF/imagen valida mediana
- archivo extension invalida
- archivo excediendo limite de tamanio
- archivo visualmente diferente para reemplazo

## 7. Convenciones de nombres de tickets de prueba
Usar source keys faciles de rastrear, por ejemplo:
- `TESTA|01|0123|20260618`
- `TESTB|01|0456|20260618`
- `TESTC|01|0789|20260618`

## 8. Consideracion de limpieza entre ciclos
Definir si el ambiente QA:
- se resetea por sprint,
- o se reutiliza acumulativamente.

### Recomendacion
Usar scripts de reseed para:
- usuarios
- tickets base
- lotes conocidos
- archivos de prueba
