# Starter Tecnico Ejecutable - Sistema Web de Gestion de Tickets de Competencia

Este starter entrega una **base ejecutable** para arrancar el backend del proyecto.

> **Importante:** este starter es una base operativa para acelerar construccion, no la implementacion final completa.
> Las reglas funcionales completas del proyecto viven en los paquetes de documentacion ya generados.

## Que incluye
- API REST en **FastAPI**
- Persistencia con **SQLAlchemy** para PostgreSQL
- Modelos base del dominio principal
- Seguridad demo por encabezado `X-Demo-User`
- Endpoints base de tickets, scan-file, integracion y admin
- Importador JSON ejecutable para procesar lotes desde carpeta local
- Datos demo de lotes JSON
- Script de bootstrap para crear tablas y usuarios demo
- Docker Compose para levantar PostgreSQL rapido

## Alcance del starter
### Si cubre
- estructura de proyecto backend
- arranque local rapido
- importador de ejemplo ejecutable
- consulta de tickets
- upload/reemplazo/confirmacion basica de scan-file a nivel app
- demo auth para pruebas rapidas

### No cubre todavia
- autenticacion productiva (JWT/Entra/LDAP)
- migraciones Alembic
- reglas blindadas con funciones SQL PostgreSQL del proyecto final
- frontend productivo
- observabilidad profunda
- pipelines CI/CD

## Estructura
```text
starter_tecnico_tickets_competencia/
  docker-compose.yml
  .env.example
  backend/
    requirements.txt
    app/
    scripts/
    data/
    storage/
```

## Requisitos recomendados
- Python 3.11+
- PostgreSQL 14+
- Pip / virtualenv
- Docker (opcional, recomendado)

## Arranque rapido (opcion con Docker para BD)
### 1) Copiar variables de entorno
```bash
cp .env.example .env
```

### 2) Levantar PostgreSQL
```bash
docker compose up -d db
```

### 3) Crear entorno virtual e instalar dependencias
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 4) Bootstrap de tablas y usuarios demo
```bash
python scripts/bootstrap_demo.py
```

### 5) Procesar lote demo
```bash
python scripts/run_importer_demo.py
```

### 6) Levantar API
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 7) Probar healthcheck
```bash
curl http://localhost:8000/api/v1/health
```

## Usuarios demo
El starter usa `DEMO_AUTH_ENABLED=true` por defecto.

Para autenticarte en local, manda el header:
```text
X-Demo-User: admin
```
o
```text
X-Demo-User: supervisor
```
o
```text
X-Demo-User: store_a
```
o
```text
X-Demo-User: store_b
```

## Endpoints base incluidos
- `GET /api/v1/health`
- `GET /api/v1/me`
- `GET /api/v1/tickets`
- `GET /api/v1/tickets/{ticketId}`
- `GET /api/v1/tickets/{ticketId}/items`
- `GET /api/v1/tickets/{ticketId}/stores`
- `GET /api/v1/tickets/{ticketId}/scan-file`
- `POST /api/v1/tickets/{ticketId}/scan-file`
- `PUT /api/v1/tickets/{ticketId}/scan-file/confirm`
- `GET /api/v1/tickets/{ticketId}/scan-file/content`
- `GET /api/v1/integration/batches`
- `GET /api/v1/integration/batches/{batchId}`
- `GET /api/v1/integration/batches/{batchId}/files`
- `GET /api/v1/integration/batches/{batchId}/errors`
- `GET /api/v1/admin/users`
- `GET /api/v1/admin/users/{userId}/stores`
- `POST /api/v1/admin/users/{userId}/stores`

## Nota tecnica importante
El proyecto final documentado recomienda que el flujo real del scan-file use **funciones SQL PostgreSQL** (`fn_replace_ticket_scan_file`, `fn_confirm_ticket_scan_file`).

Este starter implementa esa logica **en capa de aplicacion** para que sea inmediatamente ejecutable.

### Paso siguiente recomendado de endurecimiento
1. reemplazar la logica app-level de scan-file por llamadas a funciones SQL;
2. introducir migraciones;
3. sustituir demo auth por autenticacion real;
4. conectar frontend real.
