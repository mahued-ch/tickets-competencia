
# API - Archivo Escaneado

## 1. Objetivo
Definir el contrato completo del archivo escaneado:
- consultar archivo,
- subir/reemplazar archivo,
- confirmar archivo,
- visualizar metadata del archivo activo.

## 2. Principios funcionales
1. El archivo se asocia al ticket.
2. Solo un archivo activo por ticket.
3. Puede haber historial de versiones.
4. Solo se carga/reemplaza si `sourceStatusCode = '9'`.
5. Solo puede reemplazarse antes de estar confirmado.
6. Confirmado = bloqueado.

## 3. Endpoints principales
- `GET /api/v1/tickets/{ticketId}/scan-file`
- `POST /api/v1/tickets/{ticketId}/scan-file`
- `PUT /api/v1/tickets/{ticketId}/scan-file/confirm`
- `GET /api/v1/tickets/{ticketId}/scan-file/content`
- `GET /api/v1/tickets/{ticketId}/scan-file/history` (opcional recomendado)

---

## 4. Obtener resumen del archivo activo

### GET /api/v1/tickets/{ticketId}/scan-file
Devuelve metadata del archivo activo del ticket.

### Respuesta si existe archivo activo
```json
{
  "success": true,
  "data": {
    "ticketScanFileId": 501,
    "ticketId": 1001,
    "fileName": "ticket_1001_scan_v2.pdf",
    "fileExtension": "pdf",
    "mimeType": "application/pdf",
    "fileSizeBytes": 251111,
    "fileHash": "HASH_ABC_002",
    "storagePath": "/ifs/scans/ticket_1001_scan_v2.pdf",
    "storageProvider": "IFS",
    "versionNumber": 2,
    "isActive": true,
    "isConfirmed": false,
    "uploadedByUserId": 25,
    "uploadedAt": "2026-06-18T09:40:00-06:00",
    "confirmedByUserId": null,
    "confirmedAt": null,
    "notes": "Se reemplaza por imagen mas legible"
  },
  "meta": null,
  "errors": []
}
```

### Respuesta si no existe archivo
```json
{
  "success": true,
  "data": null,
  "meta": null,
  "errors": []
}
```

---

## 5. Subir o reemplazar archivo escaneado

### POST /api/v1/tickets/{ticketId}/scan-file
Este endpoint debe realizar la carga fisica y despues ejecutar la logica de reemplazo.

### Content-Type
```http
multipart/form-data
```

### Campos multipart recomendados
- `file` (obligatorio)
- `notes` (opcional)
- `storageProvider` (opcional, default `IFS`)

### Validaciones del backend antes de llamar a BD
1. ticket existe;
2. usuario autenticado;
3. usuario autorizado por rol/tienda;
4. ticket con `sourceStatusCode = '9'`;
5. extension permitida;
6. tamanio permitido;
7. hash calculado del archivo disponible si se usa.

### Proceso recomendado del backend
1. recibir archivo multipart;
2. validar tipo/tamanio;
3. guardar archivo fisico;
4. calcular `fileHash`;
5. llamar `fn_replace_ticket_scan_file`;
6. construir respuesta.

### Respuesta exitosa
`201 Created`
```json
{
  "success": true,
  "data": {
    "ticketScanFileId": 501,
    "ticketId": 1001,
    "versionNumber": 2,
    "previousTicketScanFileId": 500,
    "scanStatus": "FILE_UPLOADED",
    "hasScanFile": true
  },
  "meta": null,
  "errors": []
}
```

### Errores posibles
#### Estatus de origen invalido
`409 Conflict`
```json
{
  "success": false,
  "data": null,
  "meta": null,
  "errors": [
    {
      "code": "SCAN_UPLOAD_NOT_ALLOWED_BY_SOURCE_STATUS",
      "message": "El ticket no permite adjuntar archivo porque sourceStatusCode no es 9",
      "field": null,
      "details": {
        "ticketId": 1001,
        "sourceStatusCode": "7"
      }
    }
  ]
}
```

#### Archivo confirmado existente
`409 Conflict`
```json
{
  "success": false,
  "data": null,
  "meta": null,
  "errors": [
    {
      "code": "SCAN_FILE_ALREADY_CONFIRMED",
      "message": "El ticket ya tiene un archivo confirmado y no puede reemplazarse",
      "field": null,
      "details": {
        "ticketId": 1001
      }
    }
  ]
}
```

---

## 6. Confirmar archivo activo

### PUT /api/v1/tickets/{ticketId}/scan-file/confirm
Confirma la version activa del archivo.

### Request JSON sugerido
```json
{
  "notes": "Archivo validado y confirmado por operacion"
}
```

### Proceso backend
1. valida autorizacion;
2. llama `fn_confirm_ticket_scan_file(ticketId, currentUserId, notes)`;
3. regresa resultado.

### Respuesta exitosa
```json
{
  "success": true,
  "data": {
    "ticketScanFileId": 501,
    "ticketId": 1001,
    "versionNumber": 2,
    "confirmedAt": "2026-06-18T10:32:15-06:00",
    "scanStatus": "FILE_CONFIRMED",
    "hasScanFile": true
  },
  "meta": null,
  "errors": []
}
```

### Errores posibles
#### No hay archivo activo
`409 Conflict`
```json
{
  "success": false,
  "data": null,
  "meta": null,
  "errors": [
    {
      "code": "ACTIVE_SCAN_FILE_NOT_FOUND",
      "message": "El ticket no tiene archivo activo para confirmar",
      "field": null,
      "details": {
        "ticketId": 1001
      }
    }
  ]
}
```

#### Ya estaba confirmado
`409 Conflict`
```json
{
  "success": false,
  "data": null,
  "meta": null,
  "errors": [
    {
      "code": "SCAN_FILE_ALREADY_CONFIRMED",
      "message": "El archivo activo ya esta confirmado",
      "field": null,
      "details": {
        "ticketId": 1001
      }
    }
  ]
}
```

---

## 7. Descargar o visualizar contenido del archivo

### GET /api/v1/tickets/{ticketId}/scan-file/content
Retorna el contenido fisico del archivo activo.

### Opciones de implementacion
#### Opcion A - Streaming directo
Backend hace stream del archivo.

#### Opcion B - Redirect/presigned URL
Backend devuelve URL temporal.

### Recomendacion
Si el archivo esta en IFS o file share tradicional, usar streaming directo.

### Respuesta streaming
```http
200 OK
Content-Type: application/pdf
Content-Disposition: inline; filename="ticket_1001_scan_v2.pdf"
```

### Si se quiere forzar descarga
`Content-Disposition: attachment`

---

## 8. Historial de versiones (opcional recomendado)

### GET /api/v1/tickets/{ticketId}/scan-file/history
Devuelve historial de versiones del archivo.

### Respuesta sugerida
```json
{
  "success": true,
  "data": [
    {
      "ticketScanFileId": 500,
      "versionNumber": 1,
      "isActive": false,
      "isConfirmed": false,
      "fileName": "ticket_1001_scan_v1.pdf",
      "uploadedAt": "2026-06-18T09:20:00-06:00",
      "replacedByFileId": 501
    },
    {
      "ticketScanFileId": 501,
      "versionNumber": 2,
      "isActive": true,
      "isConfirmed": true,
      "fileName": "ticket_1001_scan_v2.pdf",
      "uploadedAt": "2026-06-18T09:40:00-06:00",
      "confirmedAt": "2026-06-18T10:32:15-06:00",
      "replacedByFileId": null
    }
  ],
  "meta": {
    "count": 2
  },
  "errors": []
}
```

## 9. Extensiones y tamanios sugeridos
Esto puede ajustarse despues, pero se sugiere permitir inicialmente:
- `pdf`
- `jpg`
- `jpeg`
- `png`

### Tamanio maximo sugerido
Definir en parametro de sistema, por ejemplo `10 MB` o `15 MB`.

## 10. Contrato backend -> funciones PostgreSQL

### Para replace/upload
Backend debe traducir el upload a esta llamada:
```sql
select * from competitor_ticket.fn_replace_ticket_scan_file(
  p_ticket_id,
  p_file_name,
  p_file_extension,
  p_mime_type,
  p_file_size_bytes,
  p_file_hash,
  p_storage_path,
  p_uploaded_by_user_id,
  p_storage_provider,
  p_notes
)
```

### Para confirm
Backend debe traducir a:
```sql
select * from competitor_ticket.fn_confirm_ticket_scan_file(
  p_ticket_id,
  p_confirmed_by_user_id,
  p_notes
)
```

## 11. Principio de implementacion
El cliente **no decide** la version del archivo. La version es calculada/controlada por BD.
