
# API - Modelos Canonicos y Codigos

## 1. Objetivo
Centralizar:
- modelos JSON canonicos,
- enumeraciones de negocio,
- codigos de error,
- tipos de evento.

## 2. Enumeraciones canonicas

## 2.1 RoleCode
```text
STORE_USER
SUPERVISOR
ADMIN
```

## 2.2 ScanStatus
```text
NO_FILE
FILE_UPLOADED
FILE_CONFIRMED
```

## 2.3 BatchStatus
```text
RECEIVED
PROCESSING
PROCESSED
PROCESSED_WITH_ERRORS
FAILED
ARCHIVED
```

## 2.4 IntegrationFileType
```text
HEADER
ITEM
STORE
CONTROL
```

## 2.5 IntegrationFileStatus
```text
RECEIVED
PROCESSING
PROCESSED
ARCHIVED
ERROR
SKIPPED
```

## 2.6 AuditEventType sugeridos
```text
BATCH_CREATED
BATCH_PROCESSED
BATCH_FAILED
TICKET_CREATED
SCAN_FILE_UPLOADED
SCAN_FILE_REPLACED
SCAN_FILE_CONFIRMED
USER_CREATED
USER_UPDATED
ROLE_ASSIGNED
STORE_ASSIGNED
```

---

## 3. Modelos canonicos de API

## 3.1 ApiError
```json
{
  "code": "TICKET_NOT_FOUND",
  "message": "No existe el ticket solicitado",
  "field": null,
  "details": null
}
```

## 3.2 ApiResponse<T>
```json
{
  "success": true,
  "data": {},
  "meta": {},
  "errors": []
}
```

## 3.3 TicketSummary
```json
{
  "ticketId": 1001,
  "sourceTicketCode": "ABCD",
  "sourceBusinessCode": "01",
  "sourceStoreCode": "1234",
  "sourceTicketDate": "2026-06-18",
  "sourceTicketKey": "ABCD|01|1234|20260618",
  "sourceStatusCode": "9",
  "scanStatus": "NO_FILE",
  "hasScanFile": false,
  "createdAt": "2026-06-18T09:15:00-06:00",
  "updatedAt": "2026-06-18T09:15:00-06:00"
}
```

## 3.4 TicketItemDto
```json
{
  "ticketItemId": 1,
  "ticketId": 1001,
  "itemSequence": 1,
  "productCode": "750100000001",
  "productDescription": "PRODUCTO DEMO 1",
  "quantity": 2.0000,
  "unitPrice": 45.5000,
  "lineAmount": 91.0000
}
```

## 3.5 TicketStoreDto
```json
{
  "ticketStoreId": 10,
  "ticketId": 1001,
  "storeCode": "0123"
}
```

## 3.6 ScanFileDto
```json
{
  "ticketScanFileId": 501,
  "ticketId": 1001,
  "fileName": "ticket_1001_scan_v2.pdf",
  "fileExtension": "pdf",
  "mimeType": "application/pdf",
  "fileSizeBytes": 251111,
  "fileHash": "HASH_ABC_002",
  "storagePath": "/ifs/scans/ticket_1001_scan_v2.pdf",
  "storageProvider": "IFS",
  "versionNumber": 2,
  "isActive": true,
  "isConfirmed": false,
  "uploadedByUserId": 25,
  "uploadedAt": "2026-06-18T09:40:00-06:00",
  "confirmedByUserId": null,
  "confirmedAt": null,
  "notes": "Se reemplaza por imagen mas legible"
}
```

## 3.7 IntegrationBatchDto
```json
{
  "batchId": 10,
  "batchCode": "20260618_090000",
  "sourceSystem": "AS400",
  "sourceDirectory": "/ifs/tickets/inbound/",
  "archiveDirectory": "/ifs/tickets/inbound/ARCHIVE/",
  "errorDirectory": "/ifs/tickets/inbound/ERROR/",
  "status": "PROCESSED",
  "headerRecordCount": 1200,
  "itemRecordCount": 8450,
  "storeRecordCount": 2400,
  "insertedTicketCount": 1189,
  "skippedTicketCount": 11,
  "errorCount": 0,
  "startedAt": "2026-06-18T09:01:00-06:00",
  "finishedAt": "2026-06-18T09:05:00-06:00"
}
```

## 3.8 AuditEventDto
```json
{
  "auditEventId": 1,
  "eventType": "SCAN_FILE_CONFIRMED",
  "entityName": "ticket_scan_file",
  "entityId": 501,
  "sourceTicketKey": "ABCD|01|1234|20260618",
  "userId": 25,
  "eventTimestamp": "2026-06-18T10:32:15-06:00",
  "oldValuesJson": {},
  "newValuesJson": {},
  "eventDetailsJson": {}
}
```

---

## 4. Codigos de error recomendados

## 4.1 Autenticacion / autorizacion
```text
UNAUTHORIZED
FORBIDDEN
USER_NOT_FOUND
USER_INACTIVE
```

## 4.2 Tickets
```text
TICKET_NOT_FOUND
TICKET_ALREADY_EXISTS
INVALID_SOURCE_TICKET_KEY
```

## 4.3 Archivo escaneado
```text
SCAN_UPLOAD_NOT_ALLOWED_BY_SOURCE_STATUS
ACTIVE_SCAN_FILE_NOT_FOUND
SCAN_FILE_ALREADY_CONFIRMED
SCAN_FILE_NOT_FOUND
INVALID_FILE_TYPE
INVALID_FILE_SIZE
FILE_STORAGE_ERROR
```

## 4.4 Integracion
```text
BATCH_NOT_FOUND
BATCH_INCOMPLETE
BATCH_FILE_NOT_FOUND
INVALID_JSON_FILE
INTEGRATION_VALIDATION_ERROR
```

## 4.5 Administracion
```text
ROLE_NOT_FOUND
STORE_ASSIGNMENT_ALREADY_EXISTS
USER_ALREADY_EXISTS
```

---

## 5. Mapeo recomendado de errores a HTTP status

### 400
- `INVALID_FILE_TYPE`
- `INVALID_FILE_SIZE`
- `INVALID_SOURCE_TICKET_KEY`
- `INVALID_JSON_FILE`

### 401
- `UNAUTHORIZED`

### 403
- `FORBIDDEN`

### 404
- `TICKET_NOT_FOUND`
- `BATCH_NOT_FOUND`
- `SCAN_FILE_NOT_FOUND`
- `ROLE_NOT_FOUND`

### 409
- `SCAN_FILE_ALREADY_CONFIRMED`
- `TICKET_ALREADY_EXISTS`
- `STORE_ASSIGNMENT_ALREADY_EXISTS`

### 422
- `SCAN_UPLOAD_NOT_ALLOWED_BY_SOURCE_STATUS`
- `INTEGRATION_VALIDATION_ERROR`

### 500
- `FILE_STORAGE_ERROR`

## 6. Principios de serializacion
- no serializar payloads raw salvo endpoints tecnicos;
- mantener estabilidad del contrato publico;
- si se agregan campos, deben ser aditivos cuando sea posible.
