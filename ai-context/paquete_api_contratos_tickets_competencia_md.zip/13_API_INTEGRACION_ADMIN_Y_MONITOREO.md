
# API - Integracion, Administracion y Monitoreo

## 1. Objetivo
Definir endpoints tecnicos/administrativos para:
- monitoreo de lotes,
- consulta de errores,
- administracion de usuarios/tiendas,
- auditoria.

## 2. Endpoints de integracion

## 2.1 Listar lotes
### GET /api/v1/integration/batches
Permite consultar lotes procesados.

### Filtros sugeridos
- `batchCode`
- `status`
- `startedAtFrom`
- `startedAtTo`
- `page`
- `pageSize`

### Respuesta sugerida
```json
{
  "success": true,
  "data": [
    {
      "batchId": 10,
      "batchCode": "20260618_090000",
      "sourceSystem": "AS400",
      "sourceDirectory": "/ifs/tickets/inbound/",
      "archiveDirectory": "/ifs/tickets/inbound/ARCHIVE/",
      "errorDirectory": "/ifs/tickets/inbound/ERROR/",
      "status": "PROCESSED",
      "headerRecordCount": 1200,
      "itemRecordCount": 8450,
      "storeRecordCount": 2400,
      "insertedTicketCount": 1189,
      "skippedTicketCount": 11,
      "errorCount": 0,
      "startedAt": "2026-06-18T09:01:00-06:00",
      "finishedAt": "2026-06-18T09:05:00-06:00"
    }
  ],
  "meta": {
    "page": 1,
    "pageSize": 20,
    "totalRecords": 1,
    "totalPages": 1
  },
  "errors": []
}
```

## 2.2 Obtener lote por ID
### GET /api/v1/integration/batches/{batchId}
Devuelve detalle del lote.

## 2.3 Obtener archivos de un lote
### GET /api/v1/integration/batches/{batchId}/files
Devuelve `integration_file` del lote.

## 2.4 Obtener errores de un lote
### GET /api/v1/integration/batches/{batchId}/errors
Devuelve errores asociados al lote.

## 2.5 Listar errores globales
### GET /api/v1/integration/errors
Filtros sugeridos:
- `batchCode`
- `entityType`
- `sourceTicketKey`
- `errorCode`
- `createdAtFrom`
- `createdAtTo`

---

## 3. Endpoints de administracion

## 3.1 Usuarios
### GET /api/v1/admin/users
Lista usuarios.

### GET /api/v1/admin/users/{userId}
Detalle de usuario.

### POST /api/v1/admin/users
Crea usuario.

### PUT /api/v1/admin/users/{userId}
Actualiza usuario.

### PATCH /api/v1/admin/users/{userId}/status
Activa/desactiva usuario.

### Contrato de alta sugerido
```json
{
  "loginName": "usuario.tienda",
  "displayName": "Usuario Tienda",
  "email": "usuario@empresa.com",
  "roleCode": "STORE_USER",
  "isActive": true
}
```

## 3.2 Roles
### GET /api/v1/admin/roles
Lista roles.

## 3.3 Asignacion de tiendas a usuario
### GET /api/v1/admin/users/{userId}/stores
Retorna tiendas asignadas.

### POST /api/v1/admin/users/{userId}/stores
Asigna tienda.

#### Request sugerido
```json
{
  "storeCode": "0123"
}
```

### DELETE /api/v1/admin/users/{userId}/stores/{storeCode}
Desasigna tienda.

#### Regla recomendada
Hacer baja logica (`isActive = false`) si se quiere conservar trazabilidad.

---

## 4. Endpoints de auditoria

### GET /api/v1/audit/events
Filtros sugeridos:
- `eventType`
- `entityName`
- `entityId`
- `sourceTicketKey`
- `userId`
- `eventTimestampFrom`
- `eventTimestampTo`
- `page`
- `pageSize`

### Respuesta sugerida
```json
{
  "success": true,
  "data": [
    {
      "auditEventId": 1,
      "eventType": "SCAN_FILE_CONFIRMED",
      "entityName": "ticket_scan_file",
      "entityId": 501,
      "sourceTicketKey": "ABCD|01|1234|20260618",
      "userId": 25,
      "eventTimestamp": "2026-06-18T10:32:15-06:00",
      "oldValuesJson": { ... },
      "newValuesJson": { ... },
      "eventDetailsJson": { ... }
    }
  ],
  "meta": {
    "page": 1,
    "pageSize": 50,
    "totalRecords": 1,
    "totalPages": 1
  },
  "errors": []
}
```

---

## 5. Dashboard operativo (opcional recomendado)

### GET /api/v1/dashboard/summary
Devuelve KPIs resumidos.

### KPIs sugeridos
- tickets integrados hoy
- tickets sin archivo
- tickets con archivo no confirmado
- tickets con archivo confirmado
- lotes procesados hoy
- lotes con error hoy

### Respuesta sugerida
```json
{
  "success": true,
  "data": {
    "ticketsIntegratedToday": 1189,
    "ticketsWithoutFile": 430,
    "ticketsWithUnconfirmedFile": 220,
    "ticketsWithConfirmedFile": 539,
    "processedBatchesToday": 3,
    "failedBatchesToday": 0
  },
  "meta": null,
  "errors": []
}
```

## 6. Matriz recomendada de acceso

### STORE_USER
- `/tickets*`: si
- `/scan-file*`: si, segun reglas
- `/integration*`: no
- `/admin*`: no
- `/audit*`: no (o muy restringido)

### SUPERVISOR
- `/tickets*`: si
- `/scan-file*`: consulta; operacion segun politica
- `/integration/batches`: opcional
- `/admin*`: no
- `/audit*`: opcional lectura

### ADMIN
- acceso total al backend funcional/administrativo

## 7. Principio de API administrativa
Todo endpoint administrativo debe:
- exigir rol `ADMIN`;
- registrar auditoria;
- evitar borrado fisico de seguridad cuando sea posible.
