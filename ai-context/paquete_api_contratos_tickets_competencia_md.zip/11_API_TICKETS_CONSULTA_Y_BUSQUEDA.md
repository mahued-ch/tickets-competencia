
# API - Tickets, Consulta y Busqueda

## 1. Objetivo
Definir los endpoints de consulta del dominio ticket.

## 2. Endpoint: buscar tickets

### GET /api/v1/tickets
Devuelve lista paginada de tickets visibles para el usuario.

## 2.1 Query params soportados
- `sourceTicketKey`
- `sourceTicketCode`
- `sourceBusinessCode`
- `sourceStoreCode`
- `sourceTicketDateFrom`
- `sourceTicketDateTo`
- `sourceStatusCode`
- `scanStatus`
- `hasScanFile`
- `storeCode`
- `batchCode`
- `page`
- `pageSize`
- `sortBy`
- `sortDirection`

## 2.2 Reglas de filtros
- `STORE_USER` no puede romper el filtro de seguridad por tienda aunque envie `storeCode` ajeno.
- `SUPERVISOR` y `ADMIN` pueden filtrar libremente.
- `sourceTicketKey` debe tener prioridad si se envia.

## 2.3 Ejemplo request
```http
GET /api/v1/tickets?sourceTicketDateFrom=2026-06-01&sourceTicketDateTo=2026-06-18&scanStatus=NO_FILE&page=1&pageSize=20&sortBy=sourceTicketDate&sortDirection=desc
```

## 2.4 Respuesta sugerida
```json
{
  "success": true,
  "data": [
    {
      "ticketId": 1001,
      "sourceTicketCode": "ABCD",
      "sourceBusinessCode": "01",
      "sourceStoreCode": "1234",
      "sourceTicketDate": "2026-06-18",
      "sourceTicketKey": "ABCD|01|1234|20260618",
      "sourceStatusCode": "9",
      "scanStatus": "NO_FILE",
      "hasScanFile": false,
      "createdAt": "2026-06-18T09:15:00-06:00",
      "updatedAt": "2026-06-18T09:15:00-06:00"
    }
  ],
  "meta": {
    "page": 1,
    "pageSize": 20,
    "totalRecords": 245,
    "totalPages": 13,
    "sortBy": "sourceTicketDate",
    "sortDirection": "desc"
  },
  "errors": []
}
```

## 3. Endpoint: obtener ticket por ID

### GET /api/v1/tickets/{ticketId}
Retorna el detalle logico del ticket.

## 3.1 Respuesta sugerida
```json
{
  "success": true,
  "data": {
    "ticket": {
      "ticketId": 1001,
      "sourceTicketCode": "ABCD",
      "sourceBusinessCode": "01",
      "sourceStoreCode": "1234",
      "sourceTicketDate": "2026-06-18",
      "sourceTicketKey": "ABCD|01|1234|20260618",
      "sourceStatusCode": "9",
      "scanStatus": "FILE_UPLOADED",
      "hasScanFile": true,
      "scanConfirmedAt": null,
      "scanConfirmedByUserId": null,
      "createdAt": "2026-06-18T09:15:00-06:00",
      "updatedAt": "2026-06-18T09:45:00-06:00"
    },
    "scanFileSummary": {
      "exists": true,
      "isConfirmed": false,
      "versionNumber": 2,
      "fileName": "ticket_1001_scan_v2.pdf",
      "mimeType": "application/pdf",
      "uploadedAt": "2026-06-18T09:40:00-06:00"
    }
  },
  "meta": null,
  "errors": []
}
```

## 4. Endpoint: obtener items del ticket

### GET /api/v1/tickets/{ticketId}/items
Retorna detalle del ticket.

## 4.1 Respuesta sugerida
```json
{
  "success": true,
  "data": [
    {
      "ticketItemId": 1,
      "ticketId": 1001,
      "itemSequence": 1,
      "productCode": "750100000001",
      "productDescription": "PRODUCTO DEMO 1",
      "quantity": 2.0000,
      "unitPrice": 45.5000,
      "lineAmount": 91.0000
    }
  ],
  "meta": {
    "count": 1
  },
  "errors": []
}
```

## 5. Endpoint: obtener tiendas del ticket

### GET /api/v1/tickets/{ticketId}/stores
Retorna distribucion de tiendas del ticket.

## 5.1 Respuesta sugerida
```json
{
  "success": true,
  "data": [
    {
      "ticketStoreId": 10,
      "ticketId": 1001,
      "storeCode": "0123"
    },
    {
      "ticketStoreId": 11,
      "ticketId": 1001,
      "storeCode": "0456"
    }
  ],
  "meta": {
    "count": 2
  },
  "errors": []
}
```

## 6. Endpoint opcional: detalle agregado del ticket

### GET /api/v1/tickets/{ticketId}/full
Puede devolver todo en una sola llamada.

### Uso recomendado
Util para la pantalla de detalle si se quiere reducir roundtrips.

### Respuesta sugerida
```json
{
  "success": true,
  "data": {
    "ticket": { ... },
    "items": [ ... ],
    "stores": [ ... ],
    "scanFileSummary": { ... }
  },
  "meta": null,
  "errors": []
}
```

## 7. Endpoint opcional: busqueda exacta por llave de negocio

### GET /api/v1/tickets/by-source-key/{sourceTicketKey}
Devuelve el ticket por llave de origen.

### Consideracion tecnica
Como `sourceTicketKey` incluye pipes (`|`), es mas seguro permitir tambien esta variante por query:

### GET /api/v1/tickets/by-source-key?value=<url-encoded>

## 8. Casos de error comunes

### Ticket inexistente
`404 Not Found`
```json
{
  "success": false,
  "data": null,
  "meta": null,
  "errors": [
    {
      "code": "TICKET_NOT_FOUND",
      "message": "No existe el ticket solicitado",
      "field": null,
      "details": {
        "ticketId": 9999
      }
    }
  ]
}
```

### Sin autorizacion por tienda
`403 Forbidden`

## 9. Campos recomendados para ordenamiento (`sortBy`)
- `sourceTicketDate`
- `createdAt`
- `updatedAt`
- `sourceStatusCode`
- `scanStatus`

## 10. Consideraciones de performance
- paginacion obligatoria;
- indices sobre fecha, status y llave;
- no traer payloads JSON crudos del ticket en endpoints de consulta normal;
- exponer payloads raw solo en endpoints tecnicos/administrativos si se requiere.
