
# API - Autenticacion y Autorizacion

## 1. Objetivo
Definir como debe autenticarse el cliente y como se aplican las reglas de autorizacion por rol y tienda.

## 2. Mecanismo recomendado
Se recomienda **Bearer Token**.

### Header esperado
```http
Authorization: Bearer <token>
```

## 3. Claims minimos recomendados del token
El sistema puede obtener estos claims desde un proveedor externo o emitir un JWT propio.

### Claims sugeridos
```json
{
  "sub": "25",
  "login": "usuario.tienda",
  "displayName": "Usuario Tienda",
  "roleCode": "STORE_USER",
  "storeCodes": ["0123", "0456"]
}
```

### Observacion
Aun si el token trae `storeCodes`, el backend debe poder refrescar/autovalidar la relacion real contra BD si la politica de seguridad lo requiere.

## 4. Roles soportados
- `STORE_USER`
- `SUPERVISOR`
- `ADMIN`

## 5. Regla general de autorizacion

### STORE_USER
Puede consultar u operar tickets **solo** si el ticket aplica a al menos una de sus tiendas.

### SUPERVISOR
Puede consultar cualquier ticket.

### ADMIN
Puede consultar cualquier ticket y administrar endpoints de seguridad/monitoreo.

## 6. Estrategia recomendada en backend

### 6.1 Middleware/Auth filter
El backend debe implementar un middleware o filtro que:
1. valide el token;
2. resuelva el usuario interno (`app_user`);
3. resuelva rol;
4. resuelva tiendas asignadas si procede;
5. inyecte contexto de seguridad a la peticion.

### 6.2 Contexto de seguridad interno sugerido
```json
{
  "userId": 25,
  "loginName": "usuario.tienda",
  "roleCode": "STORE_USER",
  "storeCodes": ["0123", "0456"]
}
```

## 7. Reglas de autorizacion por endpoint

## 7.1 Tickets - consulta
### GET /tickets
- `STORE_USER`: permitido con filtro por sus tiendas
- `SUPERVISOR`: permitido global
- `ADMIN`: permitido global

### GET /tickets/{ticketId}
- `STORE_USER`: permitido solo si el ticket pertenece a sus tiendas
- `SUPERVISOR`: permitido
- `ADMIN`: permitido

### GET /tickets/{ticketId}/items
Misma regla que `GET /tickets/{ticketId}`.

### GET /tickets/{ticketId}/stores`
Misma regla que `GET /tickets/{ticketId}`.

## 7.2 Archivo escaneado
### POST /tickets/{ticketId}/scan-file
- `STORE_USER`: permitido si el ticket es visible y `sourceStatusCode = '9'`
- `SUPERVISOR`: permitido si negocio lo autoriza; si se quiere restringir, dejarlo solo como consulta
- `ADMIN`: permitido si negocio lo autoriza

> **Recomendacion funcional**: priorizar que la carga/reemplazo/confirmacion la hagan usuarios de tienda. Supervisores y administradores pueden quedar solo de consulta si asi se define despues.

### PUT /tickets/{ticketId}/scan-file/confirm
- `STORE_USER`: permitido si tiene acceso por tienda
- `SUPERVISOR`: permitido si negocio lo autoriza
- `ADMIN`: permitido si negocio lo autoriza

### GET /tickets/{ticketId}/scan-file
- visibles para quien pueda ver el ticket

## 7.3 Monitoreo e integracion
### GET /integration/batches
- `ADMIN`: permitido
- `SUPERVISOR`: opcional segun politica de negocio
- `STORE_USER`: no permitido

### GET /integration/errors
- `ADMIN`: permitido
- `SUPERVISOR`: opcional
- `STORE_USER`: no permitido

## 7.4 Administracion
### /admin/users
### /admin/roles
### /admin/user-stores
- solo `ADMIN`

## 8. Estrategia exacta para validar visibilidad de un ticket
Dado un `ticketId` y un usuario `STORE_USER`, el backend debe validar:

```text
ticket
 -> ticket_store
 -> app_user_store
```

### Regla SQL logica
Existe autorizacion si hay al menos una fila donde:
- `ticket_store.ticket_id = :ticketId`
- `ticket_store.store_code = app_user_store.store_code`
- `app_user_store.user_id = :currentUserId`
- `app_user_store.is_active = true`

## 9. Respuestas de error de autorizacion

### 401 Unauthorized
Cuando:
- no hay token,
- token invalido,
- token expirado.

Ejemplo:
```json
{
  "success": false,
  "data": null,
  "meta": null,
  "errors": [
    {
      "code": "UNAUTHORIZED",
      "message": "Token invalido o ausente",
      "field": null,
      "details": null
    }
  ]
}
```

### 403 Forbidden
Cuando:
- el usuario esta autenticado,
- pero no tiene derecho a ver/operar el ticket.

Ejemplo:
```json
{
  "success": false,
  "data": null,
  "meta": null,
  "errors": [
    {
      "code": "FORBIDDEN",
      "message": "No tiene permisos para operar este ticket",
      "field": null,
      "details": {
        "ticketId": 1001
      }
    }
  ]
}
```

## 10. Recomendacion de implementacion
La autorizacion debe implementarse en **dos niveles**:
1. backend/API,
2. funciones/procedimientos de BD para el caso del archivo escaneado si se quiere blindaje adicional.

## 11. Endpoint opcional de perfil actual
Se recomienda exponer:

### GET /api/v1/me
Retorna el contexto de seguridad resuelto.

#### Respuesta sugerida
```json
{
  "success": true,
  "data": {
    "userId": 25,
    "loginName": "usuario.tienda",
    "displayName": "Usuario Tienda",
    "roleCode": "STORE_USER",
    "storeCodes": ["0123", "0456"]
  },
  "meta": null,
  "errors": []
}
```
