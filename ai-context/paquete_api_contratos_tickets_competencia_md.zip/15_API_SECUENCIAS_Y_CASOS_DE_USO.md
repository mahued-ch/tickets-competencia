
# API - Secuencias y Casos de Uso

## 1. Objetivo
Documentar los flujos de punta a punta mas importantes para que otra IA/ID implemente backend y frontend con el mismo entendimiento.

## 2. Caso de uso: busqueda de tickets por usuario de tienda

### Flujo
1. usuario hace login;
2. frontend obtiene contexto (`/me` o token claims);
3. frontend llama `GET /tickets` con filtros;
4. backend aplica filtro de seguridad por tienda;
5. backend devuelve solo tickets visibles;
6. frontend muestra lista.

### Regla critica
Aunque el cliente envie `storeCode`, el backend no debe devolver tickets fuera de las tiendas del usuario.

---

## 3. Caso de uso: ver detalle del ticket

### Flujo
1. usuario selecciona ticket;
2. frontend llama `GET /tickets/{ticketId}` y/o `GET /tickets/{ticketId}/full`;
3. backend valida autorizacion;
4. backend devuelve cabecera + resumen de archivo;
5. frontend puede llamar items/stores si se decidio API separada.

---

## 4. Caso de uso: carga inicial del archivo escaneado

### Precondiciones
- ticket visible para el usuario;
- `sourceStatusCode = '9'`;
- no existe archivo confirmado activo.

### Flujo
1. frontend selecciona archivo;
2. frontend envia `POST /tickets/{ticketId}/scan-file` multipart;
3. backend valida archivo;
4. backend guarda archivo fisico;
5. backend llama `fn_replace_ticket_scan_file`;
6. BD crea version 1 o la siguiente version;
7. backend responde `201 Created`;
8. frontend refresca detalle del ticket.

### Resultado esperado
- `scanStatus = FILE_UPLOADED`
- `hasScanFile = true`

---

## 5. Caso de uso: reemplazo de archivo no confirmado

### Precondiciones
- existe archivo activo;
- `isConfirmed = false`;
- ticket sigue cumpliendo reglas de seguridad y estatus 9.

### Flujo
1. frontend envia nuevo archivo al mismo endpoint POST;
2. backend guarda fisico y calcula hash;
3. backend ejecuta `fn_replace_ticket_scan_file`;
4. BD desactiva la version anterior;
5. BD inserta version nueva;
6. BD audita `SCAN_FILE_REPLACED`.

### Resultado esperado
- solo una version activa;
- historial conservado;
- ticket sigue en `FILE_UPLOADED`.

---

## 6. Caso de uso: confirmacion de archivo

### Precondiciones
- existe archivo activo;
- no esta confirmado;
- usuario autorizado.

### Flujo
1. frontend muestra boton `Confirmar`;
2. frontend llama `PUT /tickets/{ticketId}/scan-file/confirm`;
3. backend ejecuta `fn_confirm_ticket_scan_file`;
4. BD marca confirmado;
5. BD actualiza `ticket.scanStatus` a `FILE_CONFIRMED`;
6. BD audita `SCAN_FILE_CONFIRMED`;
7. frontend refresca detalle.

### Resultado esperado
- ya no se puede reemplazar;
- ya no se puede modificar;
- archivo queda solo de consulta.

---

## 7. Caso de uso: visualizar archivo escaneado

### Flujo
1. frontend llama `GET /tickets/{ticketId}/scan-file/content`;
2. backend valida acceso al ticket;
3. backend hace streaming del archivo activo;
4. navegador lo muestra inline o descarga segun `Content-Disposition`.

---

## 8. Caso de uso: monitoreo de lotes

### Flujo ADMIN
1. admin abre modulo de integracion;
2. frontend llama `GET /integration/batches`;
3. backend devuelve lotes;
4. admin entra a lote;
5. frontend llama `GET /integration/batches/{batchId}/files` y `.../errors`;
6. backend devuelve contenido;
7. admin diagnostica incidencias.

---

## 9. Caso de uso: administracion de usuarios

### Flujo ADMIN
1. admin crea usuario con `POST /admin/users`;
2. backend inserta en `app_user`;
3. admin asigna tiendas con `POST /admin/users/{userId}/stores`;
4. backend inserta en `app_user_store`;
5. admin verifica acceso.

---

## 10. Casos de error criticos que deben probarse

### 10.1 STORE_USER intentando ver ticket ajeno
Resultado esperado: `403 Forbidden`

### 10.2 Subir archivo con status distinto de 9
Resultado esperado: `409/422` segun implementacion adoptada

### 10.3 Confirmar sin archivo activo
Resultado esperado: `409 Conflict`

### 10.4 Reemplazar archivo ya confirmado
Resultado esperado: `409 Conflict`

### 10.5 Ticket inexistente
Resultado esperado: `404 Not Found`

---

## 11. Secuencia tecnica recomendada backend -> BD para archivo escaneado

### Upload/replace
```text
Controller
  -> Auth/Permission Validator
  -> File Validator
  -> File Storage Service
  -> TicketScanFileService
  -> fn_replace_ticket_scan_file()
  -> Response mapper
```

### Confirm
```text
Controller
  -> Auth/Permission Validator
  -> TicketScanFileService
  -> fn_confirm_ticket_scan_file()
  -> Response mapper
```

---

## 12. Implementacion sugerida por capas

### Capa Controller/API
- parsea request;
- valida headers/minimos;
- invoca servicios;
- serializa contratos.

### Capa Service
- aplica reglas de negocio;
- valida permisos por ticket;
- coordina storage y BD.

### Capa Repository/DB
- consultas del ticket;
- invocacion de funciones SQL;
- lectura de vistas/tablas.

### Capa Storage
- guarda y recupera archivos fisicos.

## 13. Resultado final esperado
Si otra IA/ID sigue estos contratos y secuencias, el backend quedara alineado con:
- el modelo de datos,
- las funciones de BD,
- la seguridad por rol/tienda,
- la operacion documental definida.
