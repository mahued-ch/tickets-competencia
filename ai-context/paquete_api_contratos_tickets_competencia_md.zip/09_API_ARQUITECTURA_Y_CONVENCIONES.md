
# API - Arquitectura y Convenciones

## 1. Estilo de API recomendado
Se define una **API REST JSON versionada**.

### Base path recomendado
```text
/api/v1
```

### Recursos principales
- `/tickets`
- `/tickets/{ticketId}`
- `/tickets/{ticketId}/items`
- `/tickets/{ticketId}/stores`
- `/tickets/{ticketId}/scan-file`
- `/integration/batches`
- `/integration/errors`
- `/admin/users`
- `/admin/roles`
- `/admin/user-stores`
- `/audit/events`

## 2. Formato de intercambio

### 2.1 Request/response general
- requests JSON para operaciones de negocio y consulta;
- `multipart/form-data` para carga del archivo escaneado;
- responses JSON estandarizadas.

### 2.2 Content-Type esperado
#### Operaciones JSON
```http
Content-Type: application/json
Accept: application/json
```

#### Carga de archivo
```http
Content-Type: multipart/form-data
Accept: application/json
```

## 3. Versionado
El versionado debe ir en la ruta:

```text
/api/v1
```

### Regla
Cambios incompatibles requieren nueva version (`/api/v2`).

## 4. Convenciones de nombres

### 4.1 JSON payloads
Usar `camelCase` en la API.

Ejemplo:
- `ticketId`
- `sourceTicketKey`
- `sourceStatusCode`
- `scanStatus`
- `hasScanFile`

### 4.2 Internamente en base de datos
La BD conserva convencion `snake_case`.

### Regla de mapeo
La capa backend es responsable del mapeo entre:
- API (`camelCase`)
- BD (`snake_case`)

## 5. Zona horaria y fechas

### 5.1 Fechas de negocio
Para fecha del ticket usar ISO:
```json
"sourceTicketDate": "2026-06-18"
```

### 5.2 Fechas/hora de auditoria y operacion
Usar ISO 8601 con zona:
```json
"createdAt": "2026-06-18T09:15:00-06:00"
```

## 6. Formato general de respuestas

### 6.1 Respuesta de exito simple
```json
{
  "success": true,
  "data": { ... },
  "meta": { ... },
  "errors": []
}
```

### 6.2 Respuesta de error
```json
{
  "success": false,
  "data": null,
  "meta": null,
  "errors": [
    {
      "code": "TICKET_NOT_FOUND",
      "message": "No existe el ticket solicitado",
      "field": null,
      "details": null
    }
  ]
}
```

## 7. Paginacion
Toda consulta de listas debe soportar paginacion.

### Parametros recomendados
- `page` (base 1)
- `pageSize`
- `sortBy`
- `sortDirection`

### Ejemplo
```http
GET /api/v1/tickets?page=1&pageSize=50&sortBy=sourceTicketDate&sortDirection=desc
```

### Respuesta meta recomendada
```json
"meta": {
  "page": 1,
  "pageSize": 50,
  "totalRecords": 1200,
  "totalPages": 24,
  "sortBy": "sourceTicketDate",
  "sortDirection": "desc"
}
```

## 8. Filtros
Se recomienda usar query params para busquedas.

### Ejemplo
```http
GET /api/v1/tickets?sourceTicketKey=ABC|01|1234|20260618&storeCode=0123&scanStatus=NO_FILE
```

## 9. Idempotencia

### 9.1 Consultas
GET siempre debe ser idempotente.

### 9.2 Carga/reemplazo de archivo
Puede agregarse un header opcional de idempotencia:
```http
Idempotency-Key: <uuid>
```

### Recomendacion
Si el backend lo implementa, debe evitar doble reemplazo accidental por reintentos del cliente.

## 10. Trazabilidad de request
Se recomienda soportar:
- `X-Correlation-Id`
- `X-Request-Id`

### Regla
Si el cliente no lo envia, el backend debe generarlo.

## 11. Estructura de errores
Cada error debe incluir:
- `code`
- `message`
- `field` (si aplica)
- `details` (si aplica)

## 12. HTTP status codes recomendados
- `200 OK` consulta correcta
- `201 Created` recurso creado
- `204 No Content` exito sin body
- `400 Bad Request` validacion/payload invalido
- `401 Unauthorized` no autenticado
- `403 Forbidden` sin permisos
- `404 Not Found` recurso inexistente
- `409 Conflict` violacion de regla de negocio / estado inconsistente
- `422 Unprocessable Entity` negocio no procesable
- `500 Internal Server Error` error no controlado

## 13. Recurso canonico del ticket
El recurso central del dominio es `Ticket`.

### Composicion logica de detalle del ticket
- header
- items
- stores
- scanFileSummary

## 14. Contrato canonico de `TicketSummary`
```json
{
  "ticketId": 1001,
  "sourceTicketCode": "ABCD",
  "sourceBusinessCode": "01",
  "sourceStoreCode": "1234",
  "sourceTicketDate": "2026-06-18",
  "sourceTicketKey": "ABCD|01|1234|20260618",
  "sourceStatusCode": "9",
  "scanStatus": "NO_FILE",
  "hasScanFile": false,
  "createdAt": "2026-06-18T09:15:00-06:00",
  "updatedAt": "2026-06-18T09:15:00-06:00"
}
```

## 15. Principio de implementacion
La API debe ser construida de forma que:
- la operacion viva en campos relacionales,
- el frontend no dependa de payloads JSON de origen,
- el backend traduzca el modelo interno a contratos limpios.
