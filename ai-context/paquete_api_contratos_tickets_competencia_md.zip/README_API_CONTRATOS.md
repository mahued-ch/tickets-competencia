
# Paquete de API y Contratos

## Objetivo
Este paquete documenta la **API REST**, los **contratos de entrada/salida**, las **reglas de autorizacion**, los **codigos de error**, los **flujos de uso** y las **convenciones operativas** necesarias para implementar el backend del proyecto **Sistema Web de Gestion de Tickets de Competencia**.

Esta documentacion esta pensada para que **otra IA o un equipo de desarrollo** pueda construir el backend del sistema exactamente como fue definido.

## Alcance del paquete
Este paquete cubre:

1. convenciones generales de API;
2. autenticacion y autorizacion;
3. endpoints de consulta de tickets;
4. endpoints del archivo escaneado;
5. endpoints de integracion/monitoreo y administracion;
6. modelos JSON canonicos;
7. codigos de error y reglas de validacion;
8. secuencias de uso y casos de uso operativos.

## Relacion con el paquete documental principal
Este paquete complementa la documentacion previamente generada del proyecto.

### Documentos base del proyecto ya existentes
- `README_PROYECTO_TICKETS.md`
- `01_VISION_ALCANCE_REGLAS.md`
- `02_ARQUITECTURA_E_INTEGRACION_JSON.md`
- `03_MODELO_DE_DATOS_DETALLADO.md`
- `04_DDL_POSTGRESQL.md`
- `05_DDL_SQLSERVER.md`
- `06_FUNCIONES_POSTGRESQL_ARCHIVO_ESCANEADO.md`
- `07_ROLES_SEGURIDAD_Y_OPERACION.md`
- `08_GUIA_DE_IMPLEMENTACION_PARA_OTRA_IA.md`

## Orden recomendado de lectura de este paquete
1. `09_API_ARQUITECTURA_Y_CONVENCIONES.md`
2. `10_API_AUTENTICACION_Y_AUTORIZACION.md`
3. `11_API_TICKETS_CONSULTA_Y_BUSQUEDA.md`
4. `12_API_ARCHIVO_ESCANEADO.md`
5. `13_API_INTEGRACION_ADMIN_Y_MONITOREO.md`
6. `14_API_MODELOS_Y_CODIGOS.md`
7. `15_API_SECUENCIAS_Y_CASOS_DE_USO.md`

## Principios que la API NO debe romper
1. No existe captura manual inicial del ticket.
2. El ticket base proviene de AS400.
3. El ticket es unico por la llave natural de origen.
4. El sistema es insert-only para tickets de origen.
5. El archivo escaneado solo se carga si `source_status_code = '9'`.
6. Solo existe un archivo activo por ticket.
7. El archivo puede reemplazarse solo antes de confirmar.
8. El archivo confirmado no puede modificarse ni reemplazarse.
9. `STORE_USER` solo puede operar tickets de sus tiendas.
10. `SUPERVISOR` y `ADMIN` tienen visibilidad global.

## Archivos incluidos
- `09_API_ARQUITECTURA_Y_CONVENCIONES.md`
- `10_API_AUTENTICACION_Y_AUTORIZACION.md`
- `11_API_TICKETS_CONSULTA_Y_BUSQUEDA.md`
- `12_API_ARCHIVO_ESCANEADO.md`
- `13_API_INTEGRACION_ADMIN_Y_MONITOREO.md`
- `14_API_MODELOS_Y_CODIGOS.md`
- `15_API_SECUENCIAS_Y_CASOS_DE_USO.md`

## Resultado esperado
Con este paquete, otra IA/ID debe poder construir:
- el contrato REST completo,
- el backend y sus validaciones,
- los endpoints de consulta y operacion,
- el flujo del archivo escaneado,
- y la seguridad por rol/tienda.
