
# Backend - Validaciones y Reglas

## 1. Objetivo
Definir todas las validaciones y en que capa deben ejecutarse.

## 2. Niveles de validacion

### 2.1 Nivel API
Validaciones de:
- estructura del request,
- tipos de datos,
- required fields,
- formatos basicos.

### 2.2 Nivel servicio/dominio
Validaciones de:
- existencia de recursos,
- permisos,
- estados de negocio,
- reglas de proceso.

### 2.3 Nivel BD
Validaciones de:
- integridad referencial,
- restricciones de unicidad,
- triggers de seguridad,
- funciones SQL del scan-file.

## 3. Validaciones por modulo

## 3.1 Tickets
### API
- parse de filtros;
- page/pageSize validos;
- fechas validas.

### Servicio
- ticket existe para consultas por id;
- usuario puede ver el ticket.

### BD
- unicidad de ticket por llave de negocio.

## 3.2 Archivo escaneado
### API
- archivo presente;
- tipo permitido;
- tamanio permitido.

### Servicio
- ticket existe;
- usuario autorizado;
- `sourceStatusCode = '9'`;
- no archivo confirmado activo antes de replace;
- existe archivo activo antes de confirm.

### BD
- trigger `fn_validate_ticket_scan_file`;
- trigger `fn_prevent_confirmed_scan_file_changes`;
- indice de un solo activo;
- indice de un solo confirmado.

## 3.3 Integracion
### Importador
- archivos de lote completos;
- JSON parseable;
- registros con llave minima.

### BD
- staging con constraints de unicidad por batch;
- operativa con constraints de unicidad global del ticket.

## 4. Reglas que el backend no debe duplicar innecesariamente
Si una regla critica ya existe en BD, el backend puede validarla preventivamente pero **no debe depender solo de la validacion frontend**.

## 5. Lista de reglas criticas
1. ticket visible segun rol/tienda;
2. `sourceStatusCode = '9'` para upload/replace;
3. solo un archivo activo por ticket;
4. imposible reemplazar confirmado;
5. imposible modificar/eliminar confirmado;
6. importador no sustituye tickets existentes.

## 6. Estrategia de errores recomendada
Cada validacion fallida debe traducirse a:
- excepcion de dominio;
- status HTTP adecuado;
- `ApiError.code` estable.

## 7. Ejemplos de reglas por caso

### Replace/upload
Debe fallar si:
- ticket no existe;
- usuario no autorizado;
- status de origen != 9;
- archivo tamano invalido;
- archivo tipo invalido;
- ya existe confirmado.

### Confirm
Debe fallar si:
- ticket no existe;
- usuario no autorizado;
- no hay archivo activo;
- el archivo activo ya esta confirmado.

## 8. Recomendacion de pruebas unitarias
Crear pruebas unitarias para:
- `TicketVisibilityPolicy`
- `ScanFilePolicy`
- validadores de upload
- mappers principales

## 9. Recomendacion de pruebas de integracion
Crear pruebas de integracion para:
- repositories;
- funciones SQL de scan-file;
- importador;
- endpoints criticos.
