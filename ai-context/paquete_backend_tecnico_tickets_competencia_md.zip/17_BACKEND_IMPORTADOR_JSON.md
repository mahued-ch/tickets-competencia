
# Backend - Importador JSON

## 1. Objetivo
Definir el diseno tecnico del importador que consume los archivos JSON generados en IFS y los consolida en la base de datos del sistema.

## 2. Responsabilidad del importador
El importador debe:
1. descubrir lotes pendientes;
2. validar consistencia del lote;
3. registrar el lote y sus archivos;
4. cargar staging;
5. consolidar a tablas operativas;
6. mover archivos a `ARCHIVE` o `ERROR`;
7. registrar errores.

## 3. Componentes sugeridos del importador

### 3.1 BatchDiscoveryService
- lista archivos `control_*.json`;
- deriva `batchCode`;
- verifica presencia de archivos complementarios.

### 3.2 BatchValidationService
- valida nombres y timestamp;
- valida estructura JSON;
- valida archivos esperados;
- valida `control.json`.

### 3.3 StagingLoaderService
- inserta en `integration_batch`;
- inserta en `integration_file`;
- inserta en `inbound_ticket_header/item/store`.

### 3.4 TicketConsolidationService
- toma cabeceras de staging;
- revisa duplicidad contra `ticket`;
- inserta ticket/item/store si el ticket no existe;
- marca registros inbound como procesados.

### 3.5 BatchArchiveService
- mueve archivados a `ARCHIVE`;
- mueve fallidos a `ERROR`.

## 4. Flujo tecnico detallado

```text
scan inbound/
  -> detect control_*.json
  -> derive batchCode
  -> validate header/items/stores/control
  -> create integration_batch
  -> create integration_file rows
  -> parse JSONs
  -> insert inbound rows
  -> consolidate new tickets
  -> update stats/status
  -> move files to ARCHIVE
```

## 5. Reglas exactas de descubrimiento

### 5.1 Carpeta a leer
```text
/ifs/tickets/inbound/
```

### 5.2 Patron de lote
```text
header_YYYYMMDD_HHMMSS.json
items_YYYYMMDD_HHMMSS.json
stores_YYYYMMDD_HHMMSS.json
control_YYYYMMDD_HHMMSS.json
```

### 5.3 Lote listo
Un lote se considera listo cuando existe `control_YYYYMMDD_HHMMSS.json` y los otros tres archivos esperados del mismo timestamp.

## 6. Pseudocodigo de descubrimiento

```text
for each file in inbound:
  if file matches control_*.json:
    batchCode = extract timestamp
    expected = {
      header_<batchCode>.json,
      items_<batchCode>.json,
      stores_<batchCode>.json,
      control_<batchCode>.json
    }
    if all expected exist:
      enqueue batch
    else:
      register batch incomplete
```

## 7. Validaciones minimas del lote

### 7.1 Estructura
- archivos existen;
- nombres correctos;
- timestamps coinciden.

### 7.2 Contenido JSON
- JSON parseable;
- arrays/object donde corresponda;
- campos minimos requeridos.

### 7.3 Validaciones de negocio basicas
- `header`: debe tener llave de origen;
- `item`: debe tener llave de origen y secuencia;
- `store`: debe tener llave de origen y tienda destino.

## 8. Pseudocodigo de carga a staging

```text
begin transaction
  insert integration_batch(status='PROCESSING')
  insert integration_file x 4
  parse header.json -> insert inbound_ticket_header
  parse items.json  -> insert inbound_ticket_item
  parse stores.json -> insert inbound_ticket_store
commit
```

## 9. Pseudocodigo de consolidacion operativa

```text
for each inbound header in batch:
  sourceTicketKey = build key
  if ticket exists by sourceTicketKey:
    mark skipped_ticket_count += 1
    continue
  else:
    insert ticket
    insert ticket_item rows of same sourceTicketKey
    insert ticket_store rows of same sourceTicketKey
    mark inserted_ticket_count += 1
```

## 10. Importante: politica insert-only
El importador **no actualiza** tickets ya existentes. Si el ticket ya existe:
- lo omite;
- no actualiza header;
- no actualiza items;
- no actualiza stores.

## 11. Estrategia transaccional sugerida

### Opcion recomendada
- transaccion por lote para staging;
- transaccion por ticket durante consolidacion.

### Razon
Si un ticket falla en consolidacion, el resto del lote puede continuar y el batch puede quedar `PROCESSED_WITH_ERRORS`.

## 12. Marcado de estatus del lote

### Casos
- `PROCESSED`: todo correcto
- `PROCESSED_WITH_ERRORS`: consolidacion parcial con errores
- `FAILED`: no pudo procesarse el lote
- `ARCHIVED`: archivos ya movidos a respaldo

## 13. Estrategia de errores
Cada error debe registrar:
- batch;
- archivo (si aplica);
- tipo de entidad;
- `sourceTicketKey` (si existe);
- codigo de error;
- payload fragment.

## 14. Mover a ARCHIVE o ERROR

### Si batch correcto
mover:
- `header_*`
- `items_*`
- `stores_*`
- `control_*`

a `ARCHIVE/`.

### Si batch no procesable
mover a `ERROR/` o dejar para soporte segun estrategia operativa. Si se deja en `inbound/`, debe evitarse reproceso infinito.

## 15. Scheduler recomendado
El importador debe poder ejecutarse:
- por scheduler/cron/job;
- manualmente por soporte (si se implementa una accion administrativa);
- en modo seguro/idempotente.

## 16. Interfaces tecnicas sugeridas

### ImporterRunner
- `runPendingBatches()`

### BatchProcessor
- `process(batchCode)`

### JsonParser
- `parseHeader(file)`
- `parseItems(file)`
- `parseStores(file)`
- `parseControl(file)`

### TicketConsolidator
- `consolidateBatch(batchId)`

## 17. Pruebas minimas del importador
- lote feliz;
- falta `control`;
- falta `header/items/stores`;
- JSON mal formado;
- ticket duplicado;
- item sin header;
- store sin header;
- error fisico al mover a `ARCHIVE`.
