
# Paquete Backend Tecnico del Proyecto

## Objetivo
Este paquete documenta el **diseno tecnico del backend** del proyecto **Sistema Web de Gestion de Tickets de Competencia** para que otra IA o un equipo de Ingenieria de Desarrollo pueda implementar el sistema de forma consistente con todo lo ya definido.

## Alcance del paquete
Este paquete cubre:

1. arquitectura logica del backend;
2. capas sugeridas y responsabilidades;
3. servicios de dominio;
4. repositories y accesos a BD;
5. flujo del importador JSON;
6. pseudocodigo de endpoints y casos criticos;
7. reglas de validacion y where aplicarlas;
8. estrategia de mapeo DB -> dominio -> DTO -> API;
9. plan de implementacion tecnico.

## Relacion con los paquetes anteriores
Este paquete complementa:
- la documentacion general del proyecto,
- el modelo de datos,
- el DDL PostgreSQL y SQL Server,
- las funciones de archivo escaneado,
- y el paquete de API y contratos.

## Orden recomendado de lectura
1. `16_BACKEND_ARQUITECTURA_Y_CAPAS.md`
2. `17_BACKEND_IMPORTADOR_JSON.md`
3. `18_BACKEND_SERVICIOS_Y_REPOSITORIES.md`
4. `19_BACKEND_ENDPOINTS_Y_PSEUDOCODIGO.md`
5. `20_BACKEND_MAPPERS_DTO_DOMINIO_DB.md`
6. `21_BACKEND_VALIDACIONES_Y_REGLAS.md`
7. `22_BACKEND_PLAN_DE_IMPLEMENTACION.md`

## Decisiones que este paquete asume como cerradas
- El ticket base no se captura manualmente.
- La fuente es AS400.
- La llave natural es `DGHTCK + DGHCOD + DGHSTR + DGHDAT`.
- La integracion usa JSON en IFS.
- El lote se identifica por timestamp en el nombre del archivo.
- El ticket escaneado solo se puede cargar si `source_status_code = '9'`.
- Solo un archivo activo por ticket.
- Reemplazo solo antes de confirmar.
- Confirmado = bloqueado.

## Resultado esperado
Otra IA/ID debe poder tomar este paquete y construir:
- el importador,
- el backend API,
- la capa de seguridad,
- la capa de almacenamiento de archivos,
- y la capa de uso de funciones SQL,
conforme al proyecto definido.
