
# Backend - Plan de Implementacion

## 1. Objetivo
Proponer un orden tecnico de construccion del backend para reducir riesgo y permitir entrega incremental.

## 2. Fase 1 - Fundacion

### Entregables
- estructura del proyecto backend;
- configuracion base;
- conexion a BD;
- auth middleware base;
- manejo global de errores;
- modelo de logging/correlation id.

### Checklist
- [ ] proyecto base creado
- [ ] variables de entorno definidas
- [ ] pool de conexion/config bd
- [ ] middleware auth
- [ ] exception handler global
- [ ] serializer base `ApiResponse`

## 3. Fase 2 - Lecturas del dominio ticket

### Entregables
- `GET /tickets`
- `GET /tickets/{ticketId}`
- `GET /tickets/{ticketId}/items`
- `GET /tickets/{ticketId}/stores`
- filtro por rol/tienda

### Checklist
- [ ] TicketRepository
- [ ] TicketItemRepository
- [ ] TicketStoreRepository
- [ ] TicketVisibilityPolicy
- [ ] TicketQueryService
- [ ] endpoints de lectura
- [ ] paginacion

## 4. Fase 3 - Archivo escaneado

### Entregables
- storage service
- `GET /tickets/{ticketId}/scan-file`
- `POST /tickets/{ticketId}/scan-file`
- `PUT /tickets/{ticketId}/scan-file/confirm`
- `GET /tickets/{ticketId}/scan-file/content`

### Checklist
- [ ] StorageService
- [ ] ScanFileRepository
- [ ] ScanFileSqlFunctionRepository
- [ ] ScanFilePolicy
- [ ] ScanFileService
- [ ] validacion de tamano/tipo
- [ ] streaming de contenido

## 5. Fase 4 - Integracion y monitoreo

### Entregables
- modulo importador
- `GET /integration/batches`
- archivos y errores del lote

### Checklist
- [ ] BatchDiscoveryService
- [ ] BatchValidationService
- [ ] StagingLoaderService
- [ ] TicketConsolidationService
- [ ] endpoints de monitoreo

## 6. Fase 5 - Administracion y auditoria

### Entregables
- usuarios
- asignacion de tiendas
- consulta de auditoria

### Checklist
- [ ] UserAdministrationService
- [ ] UserRepository
- [ ] UserStoreRepository
- [ ] AuditRepository
- [ ] endpoints admin
- [ ] endpoints audit

## 7. Fase 6 - Endurecimiento

### Entregables
- pruebas integrales;
- limites de archivo;
- observabilidad;
- controles de seguridad de BD;
- revisiones de performance.

### Checklist
- [ ] testing unitario
- [ ] testing integracion
- [ ] testing E2E backend
- [ ] politicas de storage
- [ ] timeouts y retries
- [ ] index tuning

## 8. Criterio de done tecnico
Backend minimo util cuando exista:
1. autenticacion;
2. consulta de tickets;
3. seguridad por tienda;
4. upload/replace/confirm de scan-file;
5. importador funcional;
6. consulta de lotes;
7. logs y errores claros.

## 9. Recomendacion final a otra IA/ID
Construir primero:
- lectura de tickets,
- luego scan-file,
- luego importador,
- luego administracion.

Esto permite validar rapidamente el dominio central antes de abordar operaciones tecnicas de soporte.
