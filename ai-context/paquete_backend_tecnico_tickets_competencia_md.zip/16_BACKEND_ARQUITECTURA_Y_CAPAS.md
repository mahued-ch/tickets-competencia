
# Backend - Arquitectura y Capas

## 1. Objetivo
Definir una arquitectura backend clara, desacoplada y mantenible.

## 2. Estilo arquitectonico recomendado
Se recomienda una arquitectura en capas con separacion clara entre:
- API/Controllers
- Application/Use Cases
- Domain/Business Rules
- Infrastructure/Repositories/Storage/DB
- Integration/Importer

## 3. Vista logica del backend

```text
[HTTP API Controllers]
        ↓
[Application Services / Use Cases]
        ↓
[Domain Rules / Security Checks / Validators]
        ↓
[Repositories / SQL Functions / Storage Services]
        ↓
[PostgreSQL + File Storage + Importer Components]
```

## 4. Modulos recomendados

### 4.1 Modulo auth
Responsabilidades:
- validar token;
- resolver usuario actual;
- resolver rol y tiendas;
- construir contexto de seguridad.

### 4.2 Modulo tickets
Responsabilidades:
- buscar tickets;
- obtener detalle del ticket;
- devolver items y stores;
- aplicar filtros y seguridad.

### 4.3 Modulo scan-file
Responsabilidades:
- validar uploads;
- guardar archivo fisico;
- invocar funciones SQL de reemplazo y confirmacion;
- devolver metadata del archivo;
- stream de contenido.

### 4.4 Modulo integration
Responsabilidades:
- monitorear lotes;
- consultar archivos de lote;
- consultar errores;
- orquestar importador si se implementa en el mismo backend.

### 4.5 Modulo admin
Responsabilidades:
- usuarios;
- roles;
- asignacion de tiendas.

### 4.6 Modulo audit
Responsabilidades:
- consulta de auditoria;
- apoyo a soporte diagnostico.

## 5. Capas recomendadas

## 5.1 API Layer
Contiene:
- controllers;
- request parsers;
- response serializers;
- error handlers HTTP.

No debe contener:
- SQL directo;
- logica de negocio compleja;
- validaciones de dominio profundas.

## 5.2 Application Layer
Contiene:
- casos de uso;
- coordinacion de servicios;
- orquestacion de workflows;
- composicion de respuestas.

Ejemplos:
- `SearchTicketsUseCase`
- `GetTicketDetailUseCase`
- `UploadOrReplaceScanFileUseCase`
- `ConfirmScanFileUseCase`
- `ListIntegrationBatchesUseCase`

## 5.3 Domain Layer
Contiene:
- reglas de negocio puras;
- evaluadores de autorizacion;
- validadores de estado;
- modelos de dominio.

Ejemplos:
- `TicketVisibilityPolicy`
- `ScanFilePolicy`
- `IntegrationBatchPolicy`

## 5.4 Infrastructure Layer
Contiene:
- repositories SQL;
- invocadores de funciones PostgreSQL;
- implementacion de storage;
- adaptadores de autenticacion;
- importador JSON.

## 6. Estructura de carpetas sugerida

```text
src/
  api/
    controllers/
    middlewares/
    schemas/
    serializers/
  application/
    use_cases/
    services/
    dto/
  domain/
    models/
    policies/
    validators/
    exceptions/
  infrastructure/
    db/
      repositories/
      sql_functions/
      mappers/
    storage/
    auth/
    integration/
      importer/
      parsers/
      processors/
  shared/
    logging/
    utils/
    config/
```

## 7. Contexto de seguridad recomendado
Cada request autenticado debe construir un objeto `SecurityContext` como minimo con:

```json
{
  "userId": 25,
  "loginName": "usuario.tienda",
  "roleCode": "STORE_USER",
  "storeCodes": ["0123", "0456"]
}
```

## 8. Datos que pertenecen a cada capa

### API
- requests/response models

### Application
- DTO internos
- casos de uso

### Domain
- entidades de dominio
- reglas de negocio

### Infrastructure
- entidades persistentes/rows
- mapeos SQL

## 9. Principio de no mezclar concerns
No mezclar:
- validaciones HTTP con reglas de negocio;
- DTO API con entidades de BD;
- autorizacion con parseo de archivos;
- importador con controllers web.

## 10. Recomendacion de transacciones
Usar transacciones backend/DB para:
- consolidacion de ticket desde staging a operativa;
- alta/reemplazo de archivo + eventuales updates de metadata;
- confirmacion de archivo;
- administracion de usuarios/tiendas cuando haya multiples pasos.

## 11. Estrategia de logging
Backend debe loguear:
- request id / correlation id;
- usuario actual;
- endpoint invocado;
- lotes procesados;
- errores controlados y no controlados;
- duracion de operaciones criticas.

## 12. Recomendacion final
Mantener el importador como modulo separado aunque corra en el mismo repo. Eso permite:
- ejecucion por scheduler;
- pruebas aisladas;
- operacion sin exponerlo a la API web.
