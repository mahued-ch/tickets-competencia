
# Backend - Servicios y Repositories

## 1. Objetivo
Definir la capa de servicios de aplicacion y los repositories requeridos para implementar el backend.

## 2. Servicios de aplicacion sugeridos

## 2.1 TicketQueryService
Responsabilidades:
- buscar tickets con filtros;
- aplicar filtro por rol/tienda;
- devolver ticket por id;
- devolver items;
- devolver stores;
- devolver detalle agregado.

### Metodos sugeridos
- `searchTickets(filters, securityContext)`
- `getTicketById(ticketId, securityContext)`
- `getTicketItems(ticketId, securityContext)`
- `getTicketStores(ticketId, securityContext)`
- `getFullTicket(ticketId, securityContext)`

## 2.2 ScanFileService
Responsabilidades:
- validar upload;
- almacenar archivo fisico;
- llamar funciones SQL de reemplazo y confirmacion;
- devolver metadata de archivo;
- exponer stream de contenido.

### Metodos sugeridos
- `getActiveScanFile(ticketId, securityContext)`
- `uploadOrReplaceScanFile(ticketId, uploadInput, securityContext)`
- `confirmScanFile(ticketId, notes, securityContext)`
- `streamActiveScanFile(ticketId, securityContext)`
- `getScanFileHistory(ticketId, securityContext)`

## 2.3 IntegrationMonitoringService
Responsabilidades:
- listar lotes;
- obtener detalle de lote;
- obtener archivos;
- obtener errores.

## 2.4 UserAdministrationService
Responsabilidades:
- crear usuario;
- actualizar usuario;
- activar/desactivar usuario;
- asignar tiendas;
- desasignar tiendas.

## 2.5 AuditQueryService
Responsabilidades:
- consultar bitacora.

---

## 3. Repositories sugeridos

## 3.1 TicketRepository
Responsabilidades:
- consultas base del ticket.

### Metodos sugeridos
- `findById(ticketId)`
- `findBySourceTicketKey(sourceTicketKey)`
- `search(filters, securityScope)`
- `existsBySourceTicketKey(sourceTicketKey)`

## 3.2 TicketItemRepository
- `findByTicketId(ticketId)`

## 3.3 TicketStoreRepository
- `findByTicketId(ticketId)`
- `existsUserAccessToTicket(ticketId, userId)`

## 3.4 ScanFileRepository
- `findActiveByTicketId(ticketId)`
- `findHistoryByTicketId(ticketId)`
- `streamMetadataByTicketId(ticketId)`

## 3.5 ScanFileSqlFunctionRepository
Responsabilidades:
- invocar funciones PostgreSQL.

### Metodos sugeridos
- `replaceTicketScanFile(params)`
- `confirmTicketScanFile(ticketId, userId, notes)`

## 3.6 IntegrationBatchRepository
- `searchBatches(filters)`
- `findBatchById(batchId)`
- `findBatchFiles(batchId)`
- `findBatchErrors(batchId)`

## 3.7 UserRepository
- `findById(userId)`
- `findByLogin(loginName)`
- `searchUsers(filters)`
- `create(user)`
- `update(user)`

## 3.8 UserStoreRepository
- `findStoresByUserId(userId)`
- `assignStore(userId, storeCode)`
- `deactivateStore(userId, storeCode)`

## 3.9 AuditRepository
- `searchEvents(filters)`

---

## 4. Politicas de dominio recomendadas

## 4.1 TicketVisibilityPolicy
Metodos sugeridos:
- `canViewTicket(securityContext, ticketId)`
- `buildSecurityScope(securityContext)`

### Regla
- `STORE_USER`: requiere match de tienda
- `SUPERVISOR`/`ADMIN`: acceso global

## 4.2 ScanFilePolicy
Metodos sugeridos:
- `canUpload(securityContext, ticket)`
- `canConfirm(securityContext, ticket)`
- `validateUploadState(ticket, activeScanFile)`

### Regla
- ticket visible;
- `sourceStatusCode == '9'`;
- no archivo confirmado activo.

---

## 5. DTO internos sugeridos

### 5.1 TicketSearchFilters
```json
{
  "sourceTicketKey": null,
  "sourceTicketCode": null,
  "sourceBusinessCode": null,
  "sourceStoreCode": null,
  "sourceTicketDateFrom": null,
  "sourceTicketDateTo": null,
  "sourceStatusCode": null,
  "scanStatus": null,
  "hasScanFile": null,
  "storeCode": null,
  "batchCode": null,
  "page": 1,
  "pageSize": 50,
  "sortBy": "sourceTicketDate",
  "sortDirection": "desc"
}
```

### 5.2 ScanFileUploadInput
```json
{
  "originalFileName": "ticket_1001.pdf",
  "fileExtension": "pdf",
  "mimeType": "application/pdf",
  "fileSizeBytes": 245678,
  "storagePath": "/ifs/scans/ticket_1001.pdf",
  "storageProvider": "IFS",
  "fileHash": "HASH001",
  "notes": "Carga inicial"
}
```

---

## 6. Llamadas recomendadas a funciones SQL

### Replace/upload
Servicio -> repository SQL:
```text
replaceTicketScanFile(
  ticketId,
  fileName,
  fileExtension,
  mimeType,
  fileSizeBytes,
  fileHash,
  storagePath,
  uploadedByUserId,
  storageProvider,
  notes
)
```

### Confirm
```text
confirmTicketScanFile(
  ticketId,
  confirmedByUserId,
  notes
)
```

---

## 7. Principio importante de implementacion
Los repositories no deben contener reglas de negocio complejas. Deben enfocarse en:
- leer y escribir datos;
- ejecutar SQL;
- mapear rows.

Las reglas complejas viven en:
- policies,
- services,
- funciones de BD (en casos seleccionados como scan-file).
