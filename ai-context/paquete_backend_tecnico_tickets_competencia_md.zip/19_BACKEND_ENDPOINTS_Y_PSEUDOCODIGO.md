
# Backend - Endpoints y Pseudocodigo

## 1. Objetivo
Mostrar como deberian implementarse los endpoints clave del backend a nivel logico.

---

## 2. GET /tickets

### Pseudocodigo
```text
controller.searchTickets(request):
  securityContext = authMiddleware.getContext()
  filters = mapQueryToTicketSearchFilters(request.query)
  result = ticketQueryService.searchTickets(filters, securityContext)
  return ok(ApiResponse.success(result.items, result.meta))
```

### Service pseudocode
```text
ticketQueryService.searchTickets(filters, securityContext):
  securityScope = ticketVisibilityPolicy.buildSecurityScope(securityContext)
  return ticketRepository.search(filters, securityScope)
```

---

## 3. GET /tickets/{ticketId}

### Pseudocodigo
```text
controller.getTicket(ticketId):
  securityContext = authMiddleware.getContext()
  dto = ticketQueryService.getTicketById(ticketId, securityContext)
  return ok(ApiResponse.success(dto))
```

### Service pseudocode
```text
ticketQueryService.getTicketById(ticketId, securityContext):
  ticket = ticketRepository.findById(ticketId)
  if ticket == null: throw TicketNotFound
  if !ticketVisibilityPolicy.canViewTicket(securityContext, ticketId): throw Forbidden
  activeScan = scanFileRepository.findActiveByTicketId(ticketId)
  return mapper.toTicketDetailDto(ticket, activeScan)
```

---

## 4. POST /tickets/{ticketId}/scan-file

### Pseudocodigo nivel controller
```text
controller.uploadScanFile(ticketId, multipartRequest):
  securityContext = authMiddleware.getContext()
  file = multipartRequest.file
  notes = multipartRequest.notes
  response = scanFileService.uploadOrReplaceScanFile(ticketId, file, notes, securityContext)
  return created(ApiResponse.success(response))
```

### Pseudocodigo nivel service
```text
scanFileService.uploadOrReplaceScanFile(ticketId, file, notes, securityContext):
  ticket = ticketRepository.findById(ticketId)
  if ticket == null: throw TicketNotFound
  if !ticketVisibilityPolicy.canViewTicket(securityContext, ticketId): throw Forbidden
  if !scanFilePolicy.canUpload(securityContext, ticket): throw Conflict/Forbidden

  fileValidator.validateType(file)
  fileValidator.validateSize(file)

  fileHash = hashService.calculate(file)
  storageResult = storageService.save(file, ticketId)

  sqlResult = scanFileSqlFunctionRepository.replaceTicketScanFile(
      ticketId=ticketId,
      fileName=storageResult.fileName,
      fileExtension=storageResult.extension,
      mimeType=storageResult.mimeType,
      fileSizeBytes=storageResult.size,
      fileHash=fileHash,
      storagePath=storageResult.path,
      uploadedByUserId=securityContext.userId,
      storageProvider=storageResult.provider,
      notes=notes
  )

  return mapper.toUploadScanFileResponse(sqlResult)
```

---

## 5. PUT /tickets/{ticketId}/scan-file/confirm

### Pseudocodigo controller
```text
controller.confirmScanFile(ticketId, body):
  securityContext = authMiddleware.getContext()
  response = scanFileService.confirmScanFile(ticketId, body.notes, securityContext)
  return ok(ApiResponse.success(response))
```

### Pseudocodigo service
```text
scanFileService.confirmScanFile(ticketId, notes, securityContext):
  ticket = ticketRepository.findById(ticketId)
  if ticket == null: throw TicketNotFound
  if !ticketVisibilityPolicy.canViewTicket(securityContext, ticketId): throw Forbidden
  if !scanFilePolicy.canConfirm(securityContext, ticket): throw Forbidden

  sqlResult = scanFileSqlFunctionRepository.confirmTicketScanFile(
      ticketId=ticketId,
      confirmedByUserId=securityContext.userId,
      notes=notes
  )

  return mapper.toConfirmScanFileResponse(sqlResult)
```

---

## 6. GET /tickets/{ticketId}/scan-file/content

### Pseudocodigo
```text
controller.streamScanFile(ticketId):
  securityContext = authMiddleware.getContext()
  metadata = scanFileService.getActiveScanFile(ticketId, securityContext)
  stream = storageService.openRead(metadata.storagePath)
  return streamResponse(stream, metadata.mimeType, metadata.fileName)
```

---

## 7. GET /integration/batches

### Pseudocodigo
```text
controller.listBatches(query):
  securityContext = authMiddleware.getContext()
  requireRole(securityContext, ADMIN or SUPERVISOR if enabled)
  filters = mapQueryToBatchFilters(query)
  result = integrationMonitoringService.searchBatches(filters)
  return ok(ApiResponse.success(result.items, result.meta))
```

---

## 8. POST /admin/users

### Pseudocodigo
```text
controller.createUser(body):
  securityContext = authMiddleware.getContext()
  requireRole(securityContext, ADMIN)
  response = userAdministrationService.createUser(body, securityContext)
  return created(ApiResponse.success(response))
```

---

## 9. Estrategia de excepciones
Servicios deben lanzar excepciones de dominio claras como:
- `TicketNotFoundException`
- `ForbiddenException`
- `InvalidFileTypeException`
- `InvalidFileSizeException`
- `ScanUploadNotAllowedException`
- `ScanFileAlreadyConfirmedException`

Un `globalExceptionHandler` debe mapear estas excepciones a:
- HTTP status
- `ApiError.code`
- `ApiError.message`

## 10. Principio de implementacion
Controllers delgados. Services orquestan. Repositories/SQL adapters ejecutan. Policies deciden. Storage abstrae el filesystem.
