
# Backend - Mappers DTO, Dominio y Base de Datos

## 1. Objetivo
Definir como debe mapearse la informacion entre las distintas capas.

## 2. Direcciones de mapeo principales

### 2.1 DB -> Domain
Rows SQL a modelos de dominio.

### 2.2 Domain -> DTO interno
Modelos de dominio a DTO de aplicacion.

### 2.3 DTO interno -> API DTO
DTO internos a contratos REST.

### 2.4 API Request -> Command/Input
Requests HTTP a comandos/casos de uso.

## 3. Principio importante
No exponer directamente filas de base de datos en la API.

## 4. Mapeo sugerido para ticket summary

### DB row ejemplo
```text
ticket_id
source_ticket_code
source_business_code
source_store_code
source_ticket_date
source_ticket_key
source_status_code
scan_status
has_scan_file
created_at
updated_at
```

### Domain model sugerido
```text
Ticket(
  id,
  sourceTicketCode,
  sourceBusinessCode,
  sourceStoreCode,
  sourceTicketDate,
  sourceTicketKey,
  sourceStatusCode,
  scanStatus,
  hasScanFile,
  createdAt,
  updatedAt
)
```

### API DTO
```json
{
  "ticketId": 1001,
  "sourceTicketCode": "ABCD",
  "sourceBusinessCode": "01",
  "sourceStoreCode": "1234",
  "sourceTicketDate": "2026-06-18",
  "sourceTicketKey": "ABCD|01|1234|20260618",
  "sourceStatusCode": "9",
  "scanStatus": "NO_FILE",
  "hasScanFile": false,
  "createdAt": "2026-06-18T09:15:00-06:00",
  "updatedAt": "2026-06-18T09:15:00-06:00"
}
```

## 5. Mapeo sugerido para detalle completo

### Domain aggregate sugerido
```text
TicketAggregate(
  ticket,
  items[],
  stores[],
  activeScanFile?
)
```

### API DTO
```json
{
  "ticket": { ... },
  "items": [ ... ],
  "stores": [ ... ],
  "scanFileSummary": { ... }
}
```

## 6. Mapeo de funciones SQL del archivo escaneado

### `fn_replace_ticket_scan_file` retorna
- `new_ticket_scan_file_id`
- `new_version_number`
- `previous_ticket_scan_file_id`

### DTO interno sugerido
```json
{
  "ticketScanFileId": 501,
  "ticketId": 1001,
  "versionNumber": 2,
  "previousTicketScanFileId": 500
}
```

### API response sugerida
```json
{
  "ticketScanFileId": 501,
  "ticketId": 1001,
  "versionNumber": 2,
  "previousTicketScanFileId": 500,
  "scanStatus": "FILE_UPLOADED",
  "hasScanFile": true
}
```

## 7. Mapeo de `fn_confirm_ticket_scan_file`

### Result SQL
- `ticket_scan_file_id`
- `ticket_id`
- `version_number`
- `confirmed_at`

### DTO interno/API
```json
{
  "ticketScanFileId": 501,
  "ticketId": 1001,
  "versionNumber": 2,
  "confirmedAt": "2026-06-18T10:32:15-06:00",
  "scanStatus": "FILE_CONFIRMED",
  "hasScanFile": true
}
```

## 8. Mapper classes sugeridas
- `TicketMapper`
- `TicketItemMapper`
- `TicketStoreMapper`
- `ScanFileMapper`
- `IntegrationBatchMapper`
- `AuditMapper`

## 9. Regla de serializacion
Todos los DTO API deben ser `camelCase`.

## 10. Recomendacion practica
Implementar mappers explicitos. Evitar mezclar modelos de BD con DTO API en los controllers.
